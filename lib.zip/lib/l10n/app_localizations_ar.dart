// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get track => 'تتبع';

  @override
  String get gold => 'ذهب';

  @override
  String get build => 'رحلتك نحو';

  @override
  String get wealth => '.الثروة';

  @override
  String get gs_subtitle =>
      'اشترِ وبِع واستثمر في محفظتك الذهبية بسهولة عبر منصة موثوقة.';

  @override
  String get login => 'تسجيل الدخول';

  @override
  String get getStarted => 'ابدأ الآن';

  @override
  String get your_gold => 'ذهبك\nثروتك';

  @override
  String get new_to_bbh => 'أنا مستخدم جديد في BBH';

  @override
  String get sign_up_bbh => 'إنشاء حساب';

  @override
  String get login_des => 'تداول وتتبع ونمِّ محفظتك من الذهب بدقة لحظية.';

  @override
  String get login_to_bbh => 'تسجيل الدخول';

  @override
  String get bank_client_onboarding => 'مصرف الطيف الإسلامي';

  @override
  String get exiting_to_bbh => 'أنا مستخدم حالي';

  @override
  String get eng_title => 'الإنجليزية';

  @override
  String get arabic_title => 'العربية';

  @override
  String get esouq_checkout_withdraw => 'الدفع عبر إي-سوق';

  @override
  String get app_lang => 'لغة التطبيق';

  @override
  String get need_help => 'بحاجة إلى مساعدة؟';

  @override
  String get email_us => 'راسلنا بالبريد';

  @override
  String get whatsapp => 'واتساب';

  @override
  String get email_not_available => 'تطبيق البريد الإلكتروني غير متوفر';

  @override
  String get whatsapp_not_available => 'واتساب غير مثبت';

  @override
  String get confirm_exit => 'تأكيد الخروج';

  @override
  String get sure_exit => 'هل أنت متأكد أنك تريد الخروج؟';

  @override
  String get yes => 'نعم';

  @override
  String get no => 'لا';

  @override
  String get contact_us => 'اتصل بنا';

  @override
  String get get_in_touch => 'تواصل معنا';

  @override
  String get contact_desc =>
      'نحن هنا لمساعدتك! اختر الطريقة المفضلة للتواصل معنا.';

  @override
  String get call_us => 'اتصل بنا';

  @override
  String get office_hours => 'ساعات العمل';

  @override
  String get office_hours_desc =>
      'الإثنين - الجمعة: 9:00 ص - 6:00 م\nالسبت: 10:00 ص - 2:00 م';

  @override
  String get welcome_back => 'مرحبًا بعودتك';

  @override
  String get welcome_back1 => 'مرحبًا بعودتك';

  @override
  String get gateway_text => 'بوابتك لبيع و شراء الذهب بطريقة آمنة وسلسة';

  @override
  String get gateway_text2 => 'تداول الذهب بأمان، في أي وقت وأي مكان.';

  @override
  String get email_or_phone => 'البريد الإلكتروني أو رقم الهاتف';

  @override
  String get password => 'كلمة المرور';

  @override
  String get forgot_password => 'هل نسيت كلمة المرور؟';

  @override
  String get loginBtn => 'تسجيل الدخول';

  @override
  String get dont_have_account => 'هل لديك حساب؟';

  @override
  String get create_account => 'إنشاء حساب';

  @override
  String get enter_phone_to_login => 'أدخل رقم هاتفك لتسجيل الدخول';

  @override
  String get enter_email_to_login => 'أدخل بريدك الإلكتروني لتسجيل الدخول';

  @override
  String get enter_bank_to_login =>
      'أدخل بياناتك البنكية لتسجيل الدخول عبر البنك';

  @override
  String get login_with_phone => 'تسجيل الدخول عبر الهاتف';

  @override
  String get login_with_email => 'تسجيل الدخول عبر البريد الإلكتروني';

  @override
  String get login_or => 'أو';

  @override
  String get forgotPassword_title => 'نسيت كلمة المرور؟';

  @override
  String get instruction =>
      'أدخل بريدك الإلكتروني أو رقم هاتفك لاستلام التعليمات لتغيير كلمة المرور الخاصة بك';

  @override
  String get change_passwordbtn => 'تغيير كلمة المرور';

  @override
  String get demo_mode => 'ملاحظة: أنت في الوضع التجريبي';

  @override
  String get createAccount_title => 'ابدأ رحلتك الذهبية';

  @override
  String get createAccount_subtitle => 'بوابتك لتداول الذهب الآمن والسلس.';

  @override
  String get createAccount_warning =>
      'تنبيه: للتحقق السريع، يرجى التأكد من أن الاسم الأول واسم العائلة وتاريخ الميلاد في مستنداتك يطابق البيانات التي تقدمها. وإلا قد يفشل التحقق بالوجه.';

  @override
  String get real_accountToggle => 'حساب حقيقي';

  @override
  String get demo_accountToggle => 'حساب تجريبي';

  @override
  String get first_name => 'الاسم الأول (الاسم القانوني)';

  @override
  String get surname => 'اسم العائلة (الاسم القانوني)';

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get phone_number => 'رقم الهاتف';

  @override
  String get confirm_password => 'تأكيد كلمة المرور';

  @override
  String get select_amount => 'اختر المبلغ';

  @override
  String get password_hint =>
      'اجمع بين الحروف الكبيرة والصغيرة والأرقام والرموز الخاصة.';

  @override
  String get create_accountbtn => 'إنشاء حساب';

  @override
  String get already_have_account => 'هل لديك حساب بالفعل؟';

  @override
  String get loginlink => 'تسجيل الدخول';

  @override
  String get agreement_text =>
      'بإنشائي حسابًا، أوافق على الشروط والأحكام وسياسة الخصوصية الخاصة بـ SaveInGold';

  @override
  String get uae_num_reg => 'يجب أن يكون رقم الإمارات مكونًا من 9 أرقام.';

  @override
  String get uae_num_str => 'يجب أن يبدأ رقم الإمارات بالرقم 5.';

  @override
  String get saudia_num => 'يجب أن يكون رقم السعودية مكونًا من 9 أرقام.';

  @override
  String get saudia_num_str => 'يجب أن يبدأ رقم السعودية بالرقم 5.';

  @override
  String get jordan_num => 'يجب أن يكون رقم الأردن مكونًا من 9 أرقام.';

  @override
  String get jordan_num_str => 'يجب أن يبدأ رقم الأردن بالرقم 7.';

  @override
  String get iraq_num => 'يجب أن يكون رقم العراق مكونًا من 10 أرقام.';

  @override
  String get iraq_num_str => 'يجب أن يبدأ رقم العراق بالرقم 7.';

  @override
  String get invalid_message_phone => 'رمز الدولة غير صالح';

  @override
  String get kyc_tell_us_about_ur => 'أخبرنا عن نفسك';

  @override
  String get kyc_refresh => 'تحديث';

  @override
  String get kyc_information =>
      'يجب أن تطابق المعلومات التالية المعلومات الموجودة في المستند الذي ستقدمه.';

  @override
  String get kyc_dob => 'تاريخ الميلاد';

  @override
  String get kyc_enter_dob => 'يرجى إدخال تاريخ الميلاد';

  @override
  String get kyc_res_cont => 'بلد الإقامة';

  @override
  String get kyc_plz_select_resd => 'يرجى اختيار الإقامة';

  @override
  String get kyc_nationality => 'الجنسية';

  @override
  String get kyc_plz_select_cont => 'يرجى اختيار الجنسية';

  @override
  String get kyc_doc_success => 'تمت إضافة المستند بنجاح!';

  @override
  String get kyc_upload_proof => 'قم برفع إثبات الإقامة (اختياري)';

  @override
  String get kyc_utility_bill => 'فاتورة خدمات أو كشف حساب بنكي';

  @override
  String get kyc_allowed_format => 'الصيغة المسموح بها PDF';

  @override
  String get kyc_select => 'اختر';

  @override
  String get kyc_failed => 'فشل في تقديم اعرف عميلك:';

  @override
  String get kyc_skip => 'تخطي الآن';

  @override
  String get kyc_identity => 'التحقق من الهوية';

  @override
  String get kyc_na_id => 'البطاقة الوطنية';

  @override
  String get kyc_em_id => 'بطاقة الهوية الإماراتية';

  @override
  String get kyc_driving => 'رخصة القيادة';

  @override
  String get kyc_passport => 'جواز السفر';

  @override
  String get kyc_get_st => 'ابدأ الآن';

  @override
  String get kyc_country => 'الدولة';

  @override
  String get kyc_upload => 'قم بتحميل';

  @override
  String get kyc_govt => 'هوية حكومية';

  @override
  String get kyc_issue =>
      ' صادرة للتحقق من هويتك بشكل آمن. المستندات التالية مقبولة:';

  @override
  String get ky_selec_cont => 'يرجى اختيار دولة';

  @override
  String get kyc_select_either => 'اختر إما';

  @override
  String get kyc_or => 'أو';

  @override
  String get kyc_select_nat => 'اختر جنسيتك';

  @override
  String get kyc_selct_res => 'اختر محل إقامتك';

  @override
  String get kyc_cancellled => 'تم إلغاء التحقق من هويتك';

  @override
  String get kyc_update_info => 'قم بتحديث معلوماتك';

  @override
  String get kyc_some_detail => 'بعض تفاصيلك غير صحيحة. يرجى التأكد من أن';

  @override
  String get kyc_match_official => 'تطابق سجلاتك الرسمية.';

  @override
  String get kyc_uhave_cancelled =>
      'لقد قمتَ بإلغاء عملية التحقق،\nانتقل إلى الشاشة الرئيسية وابدأ التحقق مرة أخرى.';

  @override
  String get kyc_go_home => 'اذهب إلى الرئيسية';

  @override
  String get kyc_update_inf => 'تحديث المعلومات';

  @override
  String get kyc_first_name => 'الاسم الأول';

  @override
  String get kyc_enter_firstname => 'أدخل اسمك الأول';

  @override
  String get kyc_last_name => 'اسم العائلة';

  @override
  String get kyc_enter_lastname => 'أدخل اسم عائلتك';

  @override
  String get name_does_not_match => 'الاسم لا يطابق سجلات التحقق (بالإنجليزية:';

  @override
  String get arabic_n => 'بالعربية:';

  @override
  String get name_kyc => 'الاسم لا يطابق سجلات التحقق:';

  @override
  String get name_native => 'الاسم لا يطابق سجلات التحقق:';

  @override
  String get dob_kyc => 'تاريخ الميلاد لا يطابق سجلات التحقق:';

  @override
  String get residency_kyc => 'دولة الإقامة لا تطابق سجلات التحقق:';

  @override
  String get nationality_kyc => 'الجنسية لا تطابق سجلات التحقق:';

  @override
  String get no_change_detected =>
      'لم يتم اكتشاف أي تغييرات. يرجى تحديث المعلومات إذا لزم الأمر.';

  @override
  String get please_enter_password => 'يرجى إدخال كلمة المرور';

  @override
  String get invalid_email_or_password =>
      'البريد الإلكتروني أو كلمة المرور غير صحيحة. حاول مرة أخرى.';

  @override
  String get please_enter_email_or_phone =>
      'يرجى إدخال البريد الإلكتروني أو رقم الهاتف';

  @override
  String get enter_email_hint => 'أدخل بريدك الإلكتروني';

  @override
  String get login_email_Labe => 'البريد الإلكتروني';

  @override
  String get login_email_validation => 'يرجى إدخال البريد الإلكتروني';

  @override
  String get please_valid_email => 'يرجى إدخال بريد إلكتروني صالح';

  @override
  String get please_enter_first_name => 'يرجى إدخال الاسم الأول';

  @override
  String get please_enter_surname => 'يرجى إدخال اسم العائلة';

  @override
  String get please_enter_email => 'يرجى إدخال البريد الإلكتروني';

  @override
  String get invalid_email => 'بريد إلكتروني غير صالح';

  @override
  String get please_enter_phone_number => 'يرجى إدخال رقم الهاتف';

  @override
  String get password_complexity_requirement =>
      'يجب أن تحتوي كلمة المرور على 8 أحرف على الأقل، بما في ذلك حرف كبير ورقم ورمز خاص';

  @override
  String get incorrect_password => 'كلمة المرور غير صحيحة';

  @override
  String get please_select_amount => 'يرجى اختيار المبلغ';

  @override
  String get deposit_amount_1m_iqd => '١ مليون دينار عراقي';

  @override
  String get deposit_amount_2m_iqd => '٢ مليون دينار عراقي';

  @override
  String get deposit_amount_3m_iqd => '٣ مليون دينار عراقي';

  @override
  String get deposit_amount_4m_iqd => '٤ مليون دينار عراقي';

  @override
  String get deposit_amount_5m_iqd => '٥ مليون دينار عراقي';

  @override
  String get confirm_pwd =>
      'كلمة المرور غير متطابقة، يرجى إعادة إدخال كلمة المرور للتأكيد.';

  @override
  String get plz_enter_valid_phone => 'يرجى إدخال رقم هاتف صالح';

  @override
  String get agreement_prefix =>
      ' بإنشائي حسابًا، أوافق على دار بغداد للسبائك الذهبية والفضية';

  @override
  String get terms_and_conditions => 'الشروط والأحكام';

  @override
  String get agreement_and => ' و ';

  @override
  String get privacy_policy => 'سياسة الخصوصية';

  @override
  String get my_account => 'حسابي';

  @override
  String get hide_balance => 'إخفاء الرصيد';

  @override
  String get show_balance => 'إظهار الرصيد';

  @override
  String get total_gold_grams => 'إجمالي الذهب (غرام)';

  @override
  String get total_funds_IQD => 'إجمالي الأموال (الدينار العراقي)';

  @override
  String get deposit => 'إيداع';

  @override
  String get latest_news => 'أحدث الأخبار';

  @override
  String get see_all => 'عرض الكل';

  @override
  String get oops_no_news => 'لا توجد أخبار متاحة حالياً. يرجى العودة لاحقاً.';

  @override
  String get news => 'الأخبار';

  @override
  String get no_news => 'لا توجد أخبار متاحة';

  @override
  String get check_back => 'تحقق لاحقًا للحصول على التحديثات';

  @override
  String get homeTab => 'الرئيسية';

  @override
  String get investTab => 'استثمار';

  @override
  String get gramsTab => 'غرامات';

  @override
  String get historyTab => 'السجل';

  @override
  String get account_details => 'تفاصيل الحساب';

  @override
  String get deposit_funds => 'إيداع الأموال';

  @override
  String get withdraw_requests => 'طلبات السحب';

  @override
  String get my_orders => 'طلباتي';

  @override
  String get esouq => 'السوق';

  @override
  String get gift => 'إهداء';

  @override
  String get support => 'الدعم';

  @override
  String get chart => 'الرسم البياني';

  @override
  String get settings => 'الإعدادات';

  @override
  String get logout => 'تسجيل الخروج';

  @override
  String get e_souq => 'إي-سوق';

  @override
  String get no_esouq_product => 'لا توجد منتجات E-Souq متاحة حالياً.';

  @override
  String get pending_sell => 'بيع قيد الانتظار';

  @override
  String get customer_support_title => 'دعم العملاء';

  @override
  String get email_us_title => 'راسلنا عبر البريد الإلكتروني';

  @override
  String get email_us_desc =>
      'هل تحتاج إلى مساعدة فورية؟ تواصل معنا عبر البريد الإلكتروني. خدمة دعم العملاء متاحة من السبت إلى الخميس من 09:00 إلى 23:00، ويوم الجمعة من 15:00 إلى 23:00 (بتوقيت العراق).';

  @override
  String get email_now => 'راسلنا الآن';

  @override
  String get call_us_title => 'اتصل الآن';

  @override
  String get call_us_desc =>
      'تحدث مباشرة مع أحد ممثلي خدمة الدعم لدينا. خدمة دعم العملاء متاحة من السبت إلى الخميس من 09:00 إلى 23:00، ويوم الجمعة من 15:00 إلى 23:00 (بتوقيت العراق).';

  @override
  String get call_now => 'اتصل بنا الآن';

  @override
  String get whatsapp_title => 'واتساب';

  @override
  String get whatsapp_desc =>
      'راسلنا عبر واتساب للحصول على دعم سريع وسهل. خدمة دعم العملاء متاحة من السبت إلى الخميس من 09:00 إلى 23:00، ويوم الجمعة من 15:00 إلى 23:00 (بتوقيت العراق).';

  @override
  String get message_on_whatsapp => 'راسلنا على واتساب';

  @override
  String get whatsapp_inbox =>
      'مرحباً فريق مبيعات Baghdad Bullion House،\n\nلتأكيد ومعالجة دفعتك، يرجى إرفاق نسخة من إيصال الدفع مع هذه الرسالة على الواتساب.\n\nسيساعدنا ذلك في التحقق من المعاملة وتحديث حسابك وفقاً لذلك.\nيمكنك ببساطة الرد على هذا البريد الإلكتروني مع إرفاق الإيصال. إذا كانت لديك أي أسئلة أو استفسارات، فلا تتردد في التواصل معنا.\n\nمع التحية،\nفريق Baghdad Bullion House.';

  @override
  String get email_message =>
      'مرحباً فريق مبيعات Baghdad Bullion House،\n\nلتأكيد ومعالجة دفعتك، يرجى إرفاق نسخة من إيصال الدفع مع هذا البريد الإلكتروني.\n\nسيساعدنا ذلك في التحقق من المعاملة وتحديث حسابك وفقاً لذلك.\nيمكنك ببساطة الرد على هذا البريد الإلكتروني مع إرفاق الإيصال. إذا كانت لديك أي أسئلة أو استفسارات، فلا تتردد في التواصل معنا.\n\nمع التحية،\nفريق Baghdad Bullion House.';

  @override
  String get email_url_title => 'إيصال الدفع عبر التحويل البنكي المباشر';

  @override
  String get biometric_title => 'بصمة';

  @override
  String get biometric_unlock => 'فتح بالبصمة';

  @override
  String get remove_biometric => 'إزالة البصمة';

  @override
  String get face_id_title => 'التعرف على الوجه';

  @override
  String get face_unlock => 'فتح بالوجه';

  @override
  String get remove_face_id => 'إزالة التعرف على الوجه';

  @override
  String get remove_title => 'إزالة';

  @override
  String get data_remove => 'سيتم حذف بياناتك البيومترية.';

  @override
  String get rem_fa_id => 'إزالة بصمة الوجه؟';

  @override
  String get wont_able_f_id =>
      'لن تتمكن من تسجيل الدخول من خلال التعرف على الوجه.';

  @override
  String get timezone_title => 'المنطقة الزمنية';

  @override
  String get timezone_select_label => 'اختر المنطقة الزمنية';

  @override
  String get timezone_error => 'لم يتم اختيار المنطقة الزمنية، يرجى تحديدها';

  @override
  String get timezone_label => 'المنطقة الزمنية';

  @override
  String get edit => 'تعديل';

  @override
  String get personalInfo_title => 'المعلومات الشخصية';

  @override
  String get pi_warning =>
      'تنبيه: تحديث معلوماتك الشخصية سيؤدي إلى تقييد مؤقت للمعاملات حتى يتم اعتمادها من فريق الدعم.';

  @override
  String get pi_first_name => 'الاسم الأول (الاسم القانوني)';

  @override
  String get pi_surname => 'اسم العائلة (الاسم القانوني)';

  @override
  String get pi_email => 'البريد الإلكتروني';

  @override
  String get pi_phone_number => 'رقم الهاتف';

  @override
  String get pi_update => 'تحديث';

  @override
  String get pi_cancel => 'إلغاء';

  @override
  String get pi_phone_exists => 'رقم الهاتف موجود بالفعل، جرب رقمًا آخر!';

  @override
  String get pi_email_exists =>
      'البريد الإلكتروني موجود بالفعل، جرب بريدًا آخر!';

  @override
  String get good_morning => 'صباح الخير';

  @override
  String get good_afternoon => 'مساء الخير';

  @override
  String get good_evening => 'مساء الخير';

  @override
  String get request_sent => 'تم إرسال رمز التحقق بنجاح';

  @override
  String get delete_account_title => 'تعطيل الحساب';

  @override
  String get delete_account_warning =>
      'تنبيه: سيؤدي تعطيل حسابك إلى تقييد الوصول. يمكنك التواصل مع فريق الدعم لدينا لإعادة تفعيله. هل أنت متأكد من المتابعة؟';

  @override
  String get delete_account_btn => 'تعطيل الحساب';

  @override
  String get delete_account_cancel => 'إلغاء';

  @override
  String get logout_popup_title => 'هل أنت متأكد أنك تريد تسجيل الخروج؟';

  @override
  String get logout_popup_desc => 'سيتم تسجيل خروجك من الحساب.';

  @override
  String get logout_yes => 'نعم';

  @override
  String get logout_no => 'لا';

  @override
  String get update_password_title => 'تحديث كلمة المرور';

  @override
  String get change_password_confirm_msg =>
      'هل أنت متأكد من تغيير كلمة المرور؟ ستحتاج إلى استخدام كلمة المرور الجديدة لتسجيل الدخول التالي.';

  @override
  String get current_password => 'أدخل كلمة المرور الحالية';

  @override
  String get current_password_label => 'كلمة المرور الحالية';

  @override
  String get new_password => 'كلمة المرور الجديدة';

  @override
  String get confirm_new_password => 'تأكيد كلمة المرور';

  @override
  String get update_password_btn => 'تحديث كلمة المرور';

  @override
  String get val_enter_current_password => 'يرجى إدخال كلمة المرور الحالية';

  @override
  String get val_enter_new_password => 'يرجى إدخال كلمة المرور الجديدة';

  @override
  String get val_enter_confirm_password => 'يرجى إدخال تأكيد كلمة المرور';

  @override
  String get val_password_rules =>
      'يجب أن تحتوي كلمة المرور على 8 أحرف على الأقل، ويجب أن تشمل حرفًا كبيرًا ورقمًا ورمزًا خاصًا.';

  @override
  String get val_passwords_do_not_match =>
      'كلمات المرور غير متطابقة. يرجى إعادة إدخال التأكيد.';

  @override
  String get val_invalid_current_password => 'كلمة المرور الحالية غير صحيحة';

  @override
  String get moneytab => 'مال';

  @override
  String get friends => 'أصدقاء';

  @override
  String get noFriendsFound => 'لم يتم العثور على أصدقاء.';

  @override
  String get receiverAccNum => 'رقم حساب المستلم';

  @override
  String get valReceiverAccNum => 'يرجى إدخال رقم حساب المستلم';

  @override
  String get receiverName => 'اسم المستلم';

  @override
  String get valReceiverName => 'يرجى إدخال اسم المستلم';

  @override
  String get receiverAccEmail => 'بريد/ الرقم المستلم';

  @override
  String get valReceiverAccEmail => 'يرجى إدخال بريد المستلم';

  @override
  String get enter_gram => 'أدخل الكمية (غرامات) هنا';

  @override
  String get enter_amount => 'أدخل المبلغ (الدينار العراقي) هنا';

  @override
  String get enter_amount_plz => 'يرجى إدخال المبلغ';

  @override
  String get enter_metal_plz => 'يرجى إدخال المعدن بالجرامات.';

  @override
  String get enter_correct_amount => 'يرجى إدخال المبلغ الصحيح';

  @override
  String get no_deals_available => 'لم يتم اختيار أي صفقات بالجرام.';

  @override
  String get valid_quantitty => 'يرجى إدخال كمية صالحة.';

  @override
  String get requested_quntity => 'الكمية المطلوبة تتجاوز الجرامات المتاحة.';

  @override
  String get gift_select_gram => 'اختر صفقة بالجرام';

  @override
  String get gift_gram_deal => 'صفقة بالجرام';

  @override
  String get gift_enter_qu => 'يرجى إدخال كمية صالحة أولاً';

  @override
  String get gift_please_choose => 'يرجى اختيار صفقة (المتاحة :';

  @override
  String get gift_leave_comment => 'اترك تعليقًا';

  @override
  String get gift_comment => 'تعليق';

  @override
  String get gift_no_deal_selected =>
      'لم يتم اختيار أي صفقة بالجرام، يرجى اختيار صفقة واحدة على الأقل للمتابعة.';

  @override
  String get gift_gram_deal_no =>
      'لم يتم اختيار أي صفقة بالجرام. يرجى اختيار الصفقات.';

  @override
  String get gift_account_not_found => 'تفاصيل الحساب غير موجودة!';

  @override
  String get gift_account_not_match =>
      'تفاصيل الحساب التي أدخلتها لا تتطابق مع سجلاتنا. يرجى التحقق من معلوماتك والمحاولة مرة أخرى.';

  @override
  String get gift_close => 'إغلاق';

  @override
  String get gift_go_back => 'العودة';

  @override
  String get gift_inavalid_amount => 'مبلغ غير صالح';

  @override
  String get gitf_valid_amount => 'يرجى إدخال مبلغ صالح.';

  @override
  String get gift_insufficient => 'الرصيد غير كافٍ';

  @override
  String get gift_add_fund => 'يرجى إضافة أموال إلى حسابك لإرسال الأموال.';

  @override
  String get gift_account_detail_found => 'تم العثور على تفاصيل الحساب!';

  @override
  String get gift_click_btn => 'انقر على الزر أدناه لإكمال هذه المعاملة.';

  @override
  String get gift_back => 'رجوع';

  @override
  String get gift_friend_del_warning => 'هل أنت متأكد أنك تريد الحذف؟';

  @override
  String get gift_search => 'بحث';

  @override
  String get gift_search_here => 'ابحث هنا';

  @override
  String get gift_selected => 'مُحدد';

  @override
  String get gift_target => 'مستهدف';

  @override
  String get gift_no_item => 'لم يتم العثور على أي عناصر';

  @override
  String get gift_to => 'إلى';

  @override
  String get gift_a_friend => 'هدية لصديق';

  @override
  String get gift_fill_form_subtitle => 'يرجى ملء النموذج أدناه لإهداء الذهب.';

  @override
  String get gift_existing_friends => 'الأصدقاء المسجّلون';

  @override
  String get gift_friend_placeholder => 'صديق';

  @override
  String get gift_hint_email_phone_sample => 'name@mail.com | 00964XXXXXXXXX';

  @override
  String get gift_label_comment_section => 'تعليق';

  @override
  String gift_success_sent_gram(String amount, String name) {
    return 'لقد أرسلت بنجاح هدية ذهبية بوزن $amount غرام إلى $name';
  }

  @override
  String get gift_success_title => 'تم إرسال الهدية!';

  @override
  String get gift_summary_title => 'ملخص';

  @override
  String get gift_summary_id_label => 'المعرّف';

  @override
  String get gift_return_home => 'العودة إلى الرئيسية';

  @override
  String get insufficient_gram_title => 'اختيار غرام غير كافٍ';

  @override
  String get ins_firt => 'الصفقات المختارة (';

  @override
  String get ins_sec => 'غ) لا تغطي المبلغ المدخل (';

  @override
  String get ins_th => 'غ). الرجاء اختيار المزيد من الصفقات أو تقليل المبلغ.';

  @override
  String get add_fund_to_buy => 'يرجى إضافة أموال إلى حسابك لشراء الذهب.';

  @override
  String get enter_email_phone => 'يرجي ادخال البريد الإلكتروني او رقم الهاتف';

  @override
  String get phAmount => 'يرجى إدخال المبلغ';

  @override
  String get comment => 'ملاحظة';

  @override
  String get continu => 'متابعة';

  @override
  String get accDetailsFound => 'تم العثور على تفاصيل الحساب!';

  @override
  String get completeTransaction => 'إكمال المعاملة';

  @override
  String get saveReceiverFriend => 'حفظ المستلم كصديق';

  @override
  String get deleteReceiverFriend => 'حذف المستلم من الأصدقاء';

  @override
  String get close => 'إغلاق';

  @override
  String get friendAdded => 'تمت إضافة الصديق بنجاح';

  @override
  String get giftSentSuccess => 'تم إرسال الهدية بنجاح.';

  @override
  String get success => 'نجاح!';

  @override
  String get giftSentMsg => 'لقد قمت بالإرسال بنجاح';

  @override
  String get returnHome => 'العودة إلى الصفحة الرئيسية';

  @override
  String get dep_selectBank_title => 'اختر البنك';

  @override
  String get dep_selectBank_sub => 'اختر البنك لتحويل المبلغ';

  @override
  String get dep_method_header => 'إضافة أموال';

  @override
  String get dep_method_sub => 'اختر طريقة';

  @override
  String get dep_method_direct => 'تحويل مباشر';

  @override
  String get dep_method_noFees => 'بدون رسوم';

  @override
  String get account_type => 'نوع الحساب';

  @override
  String get currency => 'العملة';

  @override
  String get dep_method_card => 'الدفع بالبطاقة';

  @override
  String get dep_method_google => 'Google Pay';

  @override
  String get dep_fee_instantNote => 'إيداع فوري، تطبق رسوم البنك.';

  @override
  String get dep_only_direct_title => 'تواصل مع الدعم';

  @override
  String get dep_only_direct_msg =>
      'التحويل المباشر متاح فقط. لطرق الدفع الأخرى، يرجى التواصل معنا:\n\nالهاتف: +971524378778\nالبريد الإلكتروني: mobileapp@baghdadbullionhouse.com';

  @override
  String get dep_amount_title => 'مبلغ الإيداع';

  @override
  String get dep_min_amount_note =>
      'الحد الأدنى للإيداع هو 100 الدينار العراقي، تطبق رسوم';

  @override
  String get dep_dt_intro_title => 'التحويل المباشر';

  @override
  String get dep_dt_intro_desc =>
      'يعمل التحويل المباشر مثل إرسال الأموال عبر تطبيقك البنكي. تستغرق المعاملة عادة 24 إلى 48 ساعة للتأكيد.';

  @override
  String get dep_extt_intro_desc =>
      'تعمل الحوالة الخارجية تمامًا مثل إرسال الأموال عبر تطبيقك البنكي. تستغرق المعاملة عادةً من 24 إلى 48 ساعة ليتم تأكيدها.';

  @override
  String get inst_transfer => 'تحويل فوري';

  @override
  String get ext_transfer => 'تحويل خارجي';

  @override
  String get dep_copyDetails => 'نسخ التفاصيل';

  @override
  String get dep_label_accountName => 'اسم الحساب';

  @override
  String get dep_label_accountNumber => 'رقم الحساب';

  @override
  String get dep_label_iban => 'رقم الآيبان';

  @override
  String get dep_label_swift => 'سويفت';

  @override
  String get dep_share_title => 'مشاركة الإيصال';

  @override
  String get dep_share_desc =>
      'اختر أيًا من الخيارات أدناه لمشاركة الإيصال بعد تحويل الأموال إلى حساب Baghdad Bullion House.';

  @override
  String get dep_share_whatsapp => 'مشاركة عبر واتساب';

  @override
  String get dep_share_email => 'إرسال عبر البريد الإلكتروني';

  @override
  String get dep_toast_txSaved => 'تم حفظ المعاملة بنجاح';

  @override
  String get dip_min_100 => 'الحد الأدنى للإيداع هو 100 الدينار العراقي';

  @override
  String get wait_please => 'الرجاء الإنتظار';

  @override
  String get no_banks_available => 'لا توجد بنوك متاحة';

  @override
  String get withdrawTitle => 'سحب الأموال';

  @override
  String get amountReq => 'المبلغ المطلوب';

  @override
  String get bankReq => 'اسم البنك المطلوب';

  @override
  String get beneficiary => 'اسم المستفيد';

  @override
  String get beneficiaryReq => 'اسم المستفيد المطلوب';

  @override
  String get iban => 'رقم الآيبان';

  @override
  String get ibanReq => 'رقم حساب الآيبان المطلوب';

  @override
  String get ibanLength => 'يجب أن يكون رقم الآيبان بين 21 و 34 حرفاً';

  @override
  String get withdrawBtn => 'سحب';

  @override
  String get withdrawSuccess => 'تم سحب الأموال بنجاح';

  @override
  String get withdrawSuccessTitle => 'نجاح!';

  @override
  String get withdrawSuccessMsg => 'لقد أرسلت طلب السحب بنجاح';

  @override
  String get withdrawHomeBtn => 'العودة إلى الصفحة الرئيسية';

  @override
  String get noWithdrawData => 'لم يتم العثور على قائمة عمليات السحب';

  @override
  String get enter_withdraw_amount => 'أدخل المبلغ المراد سحبه';

  @override
  String get withdraw_digit => 'يجب أن يكون المبلغ أرقامًا فقط';

  @override
  String get withdraw_enter_bank_name => 'أدخل اسم البنك';

  @override
  String get withdraw_bank_name => 'اسم البنك';

  @override
  String get withdraw_only_alphabet => 'مسموح بالأحرف فقط';

  @override
  String get withdraw_benf_name => 'أدخل اسم المستفيد';

  @override
  String get withdraw_only_alphabets => 'مسموح بالأحرف فقط';

  @override
  String get withdraw_alphabet_char => 'يجب أن يحتوي على أحرف وأرقام معًا';

  @override
  String get withdraw_add_fund => 'يرجى إضافة أموال إلى حسابك.';

  @override
  String get bank_charge_message => 'سيتم تطبيق رسوم بنكية.';

  @override
  String get save_changes => 'حفظ التغييرات';

  @override
  String get edit_bank_card => 'تعديل البطاقة البنكية';

  @override
  String get save_card_detail => 'حفظ تفاصيل البطاقة';

  @override
  String get no_save_card_found => 'لم يتم العثور على بطاقة محفوظة';

  @override
  String get card_created_successfully => 'تم إنشاء البطاقة بنجاح';

  @override
  String get card_updated_successfully => 'تم تحديث البطاقة بنجاح';

  @override
  String get card_deleted_successfully => 'تم حذف البطاقة بنجاح';

  @override
  String get card_with_draw_cancelled => 'تم إلغاء السحب بنجاح';

  @override
  String get failed_to_create_card => 'فشل في إنشاء البطاقة';

  @override
  String get failed_to_update_card => 'Failed to create card';

  @override
  String get sure_to_cancel_withdraw =>
      'هل أنت متأكد أنك تريد إلغاء طلب السحب هذا؟';

  @override
  String get withdraw_pending_block =>
      'لديك طلب سحب قيد الانتظار. يرجى انتظار معالجته أو إلغاؤه قبل إنشاء طلب جديد.';

  @override
  String get sure_want_to_delete_account_detail =>
      'هل أنت متأكد أنك تريد حذف تفاصيل الحساب البنكي المحفوظة؟.';

  @override
  String get gram_price_script => 'سعر الجرام 1';

  @override
  String get first_abudhabi => 'بنك أبوظبي الأول';

  @override
  String get mashriq_bank => 'بنك المشرق';

  @override
  String get save_inGold => 'شركة سيف إن جولد ش.ذ.م.م';

  @override
  String get features => 'المميزات';

  @override
  String get productCode => 'رمز المنتج';

  @override
  String get purity => 'النقاء';

  @override
  String get brand => 'العلامة التجارية';

  @override
  String get weight => 'الوزن';

  @override
  String get weightCategory => 'فئة الوزن';

  @override
  String get condition => 'الحالة';

  @override
  String get origin => 'المنشأ';

  @override
  String get dimensions => 'الأبعاد';

  @override
  String get inStoreCollection => 'استلام من المتجر';

  @override
  String get deliveryAvailable => 'التوصيل متاح';

  @override
  String get description => 'الوصف';

  @override
  String get shippingDelivery => 'الشحن والتوصيل';

  @override
  String get shippingFees => 'رسوم الشحن';

  @override
  String get deliveryIdentifiedPerson => 'التسليم لشخص محدد';

  @override
  String get deliveryLocation => 'موقع التوصيل';

  @override
  String get esouqCart => 'عربة السوق الإلكتروني';

  @override
  String get paymentMethod => 'طريقة الدفع';

  @override
  String get selectOption => 'اختر خيارًا';

  @override
  String get metal => 'المعادن';

  @override
  String get currentBalance => 'الرصيد الحالي';

  @override
  String get charges => 'الرسوم';

  @override
  String get goldPrice => 'سعر الذهب';

  @override
  String get premium => 'علاوة';

  @override
  String get making => 'مصنعية';

  @override
  String get vat => 'ضريبة القيمة المضافة';

  @override
  String get totalCharges => 'إجمالي الرسوم';

  @override
  String get outside_iraq => ' (خارج جمهورية العراق)';

  @override
  String get grandTotal => 'الإجمالي الكلي';

  @override
  String get buyNowBtn => 'اشترِ الآن';

  @override
  String get checkout => 'إتمام الشراء';

  @override
  String get esouq_review_order => 'مراجعة الطلب';

  @override
  String get esouq_select_document => 'اختر مستندًا';

  @override
  String get esouq_choose_file => 'ملفات';

  @override
  String get esouq_order_summary => 'ملخص الطلب';

  @override
  String get esouq_order_id => 'رقم الطلب';

  @override
  String get esouq_items => 'العناصر';

  @override
  String get esouq_total_paid => 'إجمالي المدفوع';

  @override
  String get esouq_order_placed_subtitle => 'تم تقديم طلبك بنجاح.';

  @override
  String get esouq_house_number_example => '10';

  @override
  String get esouq_weight_range => 'نطاق الوزن';

  @override
  String get esouq_bar_type => 'نوع السبيكة';

  @override
  String get delivery => 'التوصيل';

  @override
  String get collection => 'الاستلام';

  @override
  String get houseNumber => 'رقم المنزل';

  @override
  String get streetAddress => 'عنوان الشارع';

  @override
  String get roadingStreet => 'شارع رودينغ';

  @override
  String get enter_street_address => 'يرجى إدخال عنوان الشارع';

  @override
  String get enterHouseNo => 'يرجى إدخال رقم المنزل';

  @override
  String get emiratesHill => 'المنطقة السكنية';

  @override
  String get please_enter_area => 'يرجى إدخال المنطقة';

  @override
  String get will_notify_you => 'سنقوم بإبلاغك عندما يتم تنفيذ طلبك';

  @override
  String get dubai_title => 'بغداد';

  @override
  String get list_of_emirates => 'يرجى إدخال اسم المدينة';

  @override
  String get nominate_recipient => 'تعيين المستلم';

  @override
  String get nominee_name => 'اسم المرشح';

  @override
  String get upload_residency_esoq => 'تحميل إثبات الإقامة';

  @override
  String get nominee_id =>
      'يرجى تحميل بطاقة الهوية الوطنية أو بطاقة السكن للمرشح';

  @override
  String get branch_name => 'اسم الفرع';

  @override
  String get no_branch_available => 'لا توجد فروع متاحة.';

  @override
  String get no_collection_point_available => 'لا يوجد نقطة استلام متاحة';

  @override
  String get will_notify_via_email =>
      'سيتم إشعارك عبر البريد الإلكتروني بمجرد أن يكون طلبك جاهزًا للاستلام';

  @override
  String get upload_req_doc => 'يرجى تحميل المستند المطلوب';

  @override
  String get enter_nom_name => 'يرجى إدخال اسم المرشح';

  @override
  String get select_collection_branch => 'يرجى اختيار فرع الاستلام أولاً';

  @override
  String get area => 'المنطقة';

  @override
  String get emirate => 'اسم المدينة';

  @override
  String get nominateRecipient => 'تعيين مستلم';

  @override
  String get deliveryCharges => 'رسوم التوصيل';

  @override
  String get toPay => 'المبلغ المستحق';

  @override
  String get confirmPaymentBtn => 'تأكيد الدفع';

  @override
  String get dateTime => 'التاريخ والوقت';

  @override
  String get gramDeal => 'صفقة الغرام';

  @override
  String get selected => 'تم الاختيار';

  @override
  String get target => 'الهدف';

  @override
  String get doneBtn => 'تم';

  @override
  String get in_store =>
      'خدمة الاستلام من المتجر متاحة لجميع المنتجات. أوقات الاستلام من السبت إلى الخميس من 09:00 إلى 23:00، ويوم الجمعة من 15:00 إلى 23:00 (بتوقيت العراق). سيتم إرسال تأكيد عبر البريد الإلكتروني عند جاهزية طلبك للاستلام.';

  @override
  String get no_gram_deal_available => 'لا توجد صفقات غرام متاحة';

  @override
  String get plz_choose_deal => 'يرجى اختيار صفقة';

  @override
  String get select_deal_for_checkout => 'يرجى اختيار الصفقات لإتمام الشراء';

  @override
  String get all_additional_charge => 'ملاحظة: جميع الرسوم الإضافية (غرام';

  @override
  String get will_deducted => ') سيتم خصمها من رصيدك المالي';

  @override
  String get esouq_gram_balance => 'رصيد الغرام';

  @override
  String get select_checkout_deal => 'يرجى اختيار العروض لإتمام الدفع';

  @override
  String get g_less_than_req => 'الغرام أقل من المطلوب';

  @override
  String get my_orders_title => 'طلباتي';

  @override
  String get order_no => 'رقم الطلب';

  @override
  String get order_status => 'حالة الطلب';

  @override
  String get delivery_method => 'طريقة التوصيل';

  @override
  String get payment_method => 'طريقة الدفع';

  @override
  String get branch_address => 'عنوان الفرع';

  @override
  String get quantity => 'الكمية';

  @override
  String get pending => 'قيد الانتظار';

  @override
  String get pickup => 'استلام';

  @override
  String get order_details => 'تفاصيل الطلب';

  @override
  String get customer_address => 'عنوان العميل';

  @override
  String get metal_released => 'تم تحرير المعدن';

  @override
  String get metal_holder => 'Metal Holder';

  @override
  String get history => 'السجل';

  @override
  String get money => 'الأموال';

  @override
  String get transactionID => 'معرّف المعاملة';

  @override
  String get esouqPayment => 'دفع إي سوق';

  @override
  String get goldDebit => 'خصم ذهب';

  @override
  String get goldCredit => 'رصيد ذهب';

  @override
  String get balanceAfterTrade => 'الرصيد بعد البيع أو الشراء';

  @override
  String get balanceAfterTransaction => 'الرصيد بعد المعاملة';

  @override
  String get transactionType => 'نوع المعاملة';

  @override
  String get sold => 'تم البيع';

  @override
  String get purchased => 'تم الشراء';

  @override
  String get invest => 'استثمر';

  @override
  String get sigWallet => 'محفظة SIG';

  @override
  String get moneyIn => 'إيداع';

  @override
  String get moneyOut => 'سحب';

  @override
  String get debit => 'خصم';

  @override
  String get credit => 'رصيد';

  @override
  String get transactionMethod => 'طريقة المعاملة';

  @override
  String get metal_st => 'كشف المعادن';

  @override
  String get money_st => 'كشف الحساب المالي';

  @override
  String get money_tx_credit_in => 'إضافة رصيد';

  @override
  String get money_tx_money_in => 'إيداع نقدي';

  @override
  String get money_tx_money_out => 'سحب نقدي';

  @override
  String get money_tx_credit_out => 'خصم رصيد';

  @override
  String get money_tx_deposit => 'إيداع';

  @override
  String get money_tx_withdraw => 'سحب';

  @override
  String get money_tx_adjustment => 'تعديل';

  @override
  String get money_tx_loan_credit_out => 'سحب قرض';

  @override
  String get money_tx_cashback => 'استرداد نقدي';

  @override
  String get money_tx_referral_cashback => 'استرداد نقدي للإحالة';

  @override
  String get money_tx_covering_purchase => 'تغطية عملية الشراء';

  @override
  String get money_tx_proceeds_sale => 'عائدات البيع';

  @override
  String get money_tx_invest => 'استثمار';

  @override
  String get money_tx_withdraw_invest => 'سحب استثمار';

  @override
  String get money_tx_transfer => 'تحويل';

  @override
  String get money_tx_received => 'استلام';

  @override
  String get money_tx_failed_transfer_adjustment => 'تسوية تحويل فاشل';

  @override
  String get money_tx_reward => 'مكافأة';

  @override
  String get money_tx_gift => 'هدية';

  @override
  String get money_tx_gift_sent => 'إرسال هدية';

  @override
  String get money_tx_gift_received => 'استلام هدية';

  @override
  String get money_tx_temporary_credit => 'ائتمان مؤقت';

  @override
  String money_history_gram_purchase_line(String iqd, String grams) {
    return 'دينار عراقي $iqd، تغطية شراء $grams من ذهب';
  }

  @override
  String money_history_gram_sale_line(String iqd, String grams) {
    return 'دينار عراقي $iqd، متحصلات من بيع $grams من الذهب';
  }

  @override
  String get metal_rate_IQD => 'السعر: الدينار العراقي إماراتي';

  @override
  String get metal_g => 'غرام';

  @override
  String withdraw_success(Object amount) {
    return 'تم خصم مبلغ $amount الدينار العراقي من حسابك.';
  }

  @override
  String deposit_success(Object amount) {
    return 'تم إضافة $amount الدينار العراقي إلى حسابك.';
  }

  @override
  String get login_success => 'تم تسجيل الدخول إلى حسابك بنجاح.';

  @override
  String get logout_success => 'تم تسجيل الخروج من حسابك بنجاح.';

  @override
  String gift_sent(Object amount, Object recipient) {
    return 'لقد أرسلت بنجاح هدية بقيمة $amount الدينار العراقي إلى $recipient.';
  }

  @override
  String get esouq_order =>
      'تم تقديم طلبك في السوق الإلكتروني وسيتم معالجته قريبًا.';

  @override
  String buy_order_filled(Object dealId, Object price, Object quantity) {
    return 'لقد اشتريت $quantity غرام من الذهب بسعر $price الدينار العراقي. رقم الصفقة: $dealId.';
  }

  @override
  String get no_notification => 'لم يتم العثور على إشعارات';

  @override
  String get invest_title => 'استثمار';

  @override
  String get selling_price => 'سعر البيع';

  @override
  String get buying_price => 'سعر الشراء';

  @override
  String get low => 'الأدنى:';

  @override
  String get high => 'الأعلى:';

  @override
  String get price => 'السعر ';

  @override
  String get max_grams_note => 'أقصى عدد غرامات يمكنك شراؤها:';

  @override
  String get buy_at_price => 'شراء بالسعر';

  @override
  String get buy_gold_btn => 'اشترِ الذهب';

  @override
  String get buy_gold_pop => 'سعر الذهب:';

  @override
  String get sec => 'ثانية';

  @override
  String get invest_invalid_amount => 'قيمة غير صالحة. يرجى إدخال رقم صحيح.';

  @override
  String get invest_price_less_than_buying =>
      'أدخل سعراً أقل من أو يساوي سعر الشراء الحالي.';

  @override
  String get invest_insufficient_balance_title => 'رصيد غير كافٍ';

  @override
  String invest_insufficient_balance_desc(Object balance, Object required) {
    return 'رصيدك (الدينار العراقي $balance) أقل من المبلغ المطلوب (الدينار العراقي $required). يرجى إضافة أموال.';
  }

  @override
  String get invest_confirmation_title => 'تأكيد';

  @override
  String invest_confirmation_message(String grams) {
    return 'هل ترغب في شراء $grams غرام من الذهب الآن؟';
  }

  @override
  String get invest_filled_oreder => 'تم تنفيذ أمر الشراء';

  @override
  String get invest_successfully_submitted =>
      'تم إرسال أمر الشراء الخاص بك بنجاح للمعالجة.';

  @override
  String get invest_sell_order_placed => 'تم إنشاء أمر البيع';

  @override
  String get invest_sell_order_filled => 'تم تنفيذ أمر البيع';

  @override
  String get invest_sell_order_submitted_success =>
      'تم إرسال أمر البيع الخاص بك بنجاح للمعالجة.';

  @override
  String get invest_order_placed => 'تم إنشاء أمر الشراء';

  @override
  String insufficient_balance_message(
    String walletBalance,
    String inputAmount,
  ) {
    return 'رصيدك (الدينار العراقي إماراتي $walletBalance) أقل من المبلغ المطلوب (الدينار العراقي إماراتي $inputAmount). يرجى إضافة الأموال.';
  }

  @override
  String get iqd_currency => 'دينار عراقي';

  @override
  String get iqd_gram => 'غرام';

  @override
  String get invest_confirm_purchase_btn => 'تأكيد الشراء';

  @override
  String get invest_add_funds_btn => 'إضافة أموال';

  @override
  String get re_submit_document => 'إعادة إرسال المستندات';

  @override
  String get dealDetails_title => 'تفاصيل الصفقة';

  @override
  String get deal_buy_order => 'أمر شراء';

  @override
  String get deal_at_price => 'بسعر';

  @override
  String get deal_id_label => 'معرّف الصفقة';

  @override
  String deal_buy_order_title(Object grams) {
    return 'طلب شراء $gramsغ ذهب';
  }

  @override
  String get deal_buy_at_price => 'اشترِ بسعر';

  @override
  String get deal_current_sell_price => 'سعر البيع الحالي';

  @override
  String get deal_current_buy_price => 'سعر الشراء الحالي';

  @override
  String get deal_invest_money => 'المبلغ المستثمر';

  @override
  String get deal_manage_section => 'إدارة الصفقة';

  @override
  String get deal_take_profit => 'أمر محدد';

  @override
  String get deal_sell_at_price => 'بيع بسعر';

  @override
  String get deal_save_profit => 'حفظ الربح';

  @override
  String deal_save_profit_hint(String boughtAt, String currentPrice) {
    return 'أدخل قيمة بين سعر الشراء ($boughtAt) والسعر الحالي ($currentPrice)';
  }

  @override
  String deal_take_profit_grams(String total) {
    return 'غرامات (الحد الأقصى $total)';
  }

  @override
  String deal_grams_must_be_less_or_equal(String total) {
    return 'يجب أن تكون الكمية أقل من أو تساوي $total غرام';
  }

  @override
  String get deal_update_position_btn => 'تحديث موقع الصفقة';

  @override
  String get deal_close_section => 'بيع بسعر السوق';

  @override
  String get deal_amount_gram => 'كمية بالغرام';

  @override
  String get deal_val_enter_amount => 'يرجى إدخال كمية';

  @override
  String get metal_after_trade => 'المعدن بعد التداول';

  @override
  String get metal_profit => 'الربح';

  @override
  String get metal_loss => 'خسارة';

  @override
  String get metal_plus_na => '+ الدينار العراقي غير متاح';

  @override
  String get deal_cant_close => 'لا يمكنك إغلاق هذه الصفقة بخسارة.';

  @override
  String deal_price_greater_or_equal_buy_at(Object price) {
    return 'أدخل سعراً أكبر من أو يساوي سعر الشراء ($price).';
  }

  @override
  String get deal_cannot_close_at_loss => 'لا يمكنك إغلاق هذه الصفقة بخسارة';

  @override
  String get deal_enter_valid_profit_price =>
      'يرجى إدخال سعر ربح صالح للاستخدام.';

  @override
  String get greater_or_equal_buy =>
      'أدخل سعرًا أكبر من أو يساوي سعر الشراء الحالي (';

  @override
  String get greater_or_equal_sell =>
      'أدخل سعرًا أكبر من أو يساوي سعر البيع الحالي (';

  @override
  String get cant_close_at_loss => 'لا يمكنك إغلاق هذه الصفقة بخسارة';

  @override
  String get deal_update_confirm_title => 'تأكيد';

  @override
  String get deal_update_confirm_message =>
      'هل أنت متأكد أنك تريد تحديث موقع الصفقة؟';

  @override
  String get gramsBalance_title => 'رصيدك من الذهب (بالغرام)';

  @override
  String get grams_card_buy_at_price_order => 'طلب شراء بسعر';

  @override
  String get grams_card_invest_money => 'المبلغ المستثمر:';

  @override
  String get grams_card_invest_status => 'حالة الاستثمار:';

  @override
  String get grams_card_opened => 'معبأة';

  @override
  String get grams_card_date_label => 'التاريخ:';

  @override
  String get gram_bar_nmbr => 'رقم السبيكة :';

  @override
  String get gram_status => 'الحالة';

  @override
  String get gram_target_price => 'السعر المستهدف';

  @override
  String get gram_current_price => 'السعر الحالي';

  @override
  String get invest_buy_at_price_update_success =>
      'تم تحديث طلب الشراء بسعر بنجاح';

  @override
  String get buy_order_updated_title => 'تم تحديث طلب الشراء!';

  @override
  String get buy_order_updated_desc => 'لقد قمت بتحديث طلب الشراء بسعر بنجاح';

  @override
  String get history_statement_exported => 'تم تصدير الكشف بنجاح';

  @override
  String get history_bought_label => 'تم الشراء';

  @override
  String get history_rate_label => 'معدل الفائدة';

  @override
  String get notification => 'الإشعارات';

  @override
  String get history_create_money_st =>
      'يرجى إنشاء كشف مالي جديد أو المحاولة لاحقاً';

  @override
  String get history_create_metal_st =>
      'يرجى إنشاء كشف معدن جديد أو المحاولة لاحقاً';

  @override
  String get history_filters_title => 'التصفية';

  @override
  String get history_filters_show_from => 'عرض السجل من';

  @override
  String get history_filters_all => 'الكل';

  @override
  String get history_filters_today => 'اليوم';

  @override
  String get history_filters_this_week => 'هذا الأسبوع';

  @override
  String get history_filters_this_month => 'هذا الشهر';

  @override
  String get history_filters_custom => 'مخصص';

  @override
  String get history_filters_from => 'من';

  @override
  String get history_filters_to => 'إلى';

  @override
  String get history_filters_apply_btn => 'تطبيق التصفية';

  @override
  String get history_filters_clear_btn => 'مسح التصفية';

  @override
  String get empty_no_data => 'لا توجد بيانات للعرض';

  @override
  String get order_no_data_to_show =>
      'ليس لديك أي طلبات حالية أو سابقة حتى الآن.';

  @override
  String get empty_email_not_verified => 'بريدك الإلكتروني غير مُحقق';

  @override
  String get empty_no_gram_balance => 'لا يوجد رصيد بالغرام';

  @override
  String get email_verification_required => 'التحقق من البريد الإلكتروني مطلوب';

  @override
  String get email_verification_msg =>
      'يجب عليك التحقق من بريدك الإلكتروني أولاً. هل تريد التحقق الآن؟';

  @override
  String get email_verification_verify_btn => 'تحقق';

  @override
  String get email_verification_cancel_btn => 'إلغاء';

  @override
  String get settings_title => 'الإعدادات';

  @override
  String get settings_personal_info => 'المعلومات الشخصية';

  @override
  String get settings_personal_info_desc =>
      'إدارة بياناتك الشخصية وتفضيلاتك في التطبيق.';

  @override
  String get settings_language => 'إعدادات اللغة';

  @override
  String get settings_language_desc => 'اختر لغة التطبيق المفضلة لديك.';

  @override
  String get settings_switch => 'نوع الحساب';

  @override
  String get settings_switch_desc => 'التحويل من حساب تجريبي إلى حساب حقيقي';

  @override
  String get settings_biometric => 'تمكين تسجيل الدخول البيومتري';

  @override
  String get settings_biometric_desc =>
      'سجّل الدخول بأمان باستخدام التعرف على الوجه أو بصمة الإصبع.';

  @override
  String get settings_timezone => 'المنطقة الزمنية';

  @override
  String get settings_timezone_desc => 'اضبط المنطقة الزمنية لتطابق موقعك.';

  @override
  String get settings_password => 'إعدادات كلمة المرور';

  @override
  String get settings_password_desc => 'تحديث كلمة مرور حسابك.';

  @override
  String get settings_delete => 'تعطيل الحساب';

  @override
  String get settings_delete_desc => 'تعطيل حسابك مؤقتًا';

  @override
  String get settings_logout => 'تسجيل الخروج';

  @override
  String get settings_logout_desc => 'تسجيل الخروج من حسابك بأمان.';

  @override
  String get settings_build_env_staging => 'تجريبي';

  @override
  String get settings_build_env_live => 'إنتاج';

  @override
  String settings_app_version_footer(
    String versionWord,
    String buildNumber,
    String environment,
  ) {
    return '$versionWord $buildNumber-$environment';
  }

  @override
  String account_warning(String kycStatus) {
    return 'يرجى التحقق من $kycStatus للحصول على إمكانية الوصول إلى جميع الميزات.';
  }

  @override
  String get verify_account => 'التحقق من الحساب';

  @override
  String get kyc_doc_national_id => 'البطاقة الوطنية';

  @override
  String get kyc_doc_passport => 'جواز السفر';

  @override
  String get kyc_doc_residency => 'وثيقة الإقامة';

  @override
  String kyc_document_rejected(String document) {
    return 'تم رفض $document. اضغط للتحديث وإعادة الإرسال.';
  }

  @override
  String kyc_document_pending(String document) {
    return 'ما زال $document قيد المراجعة. اضغط للتحديث.';
  }

  @override
  String get kyc_retake_document => 'إعادة التقاط الوثيقة';

  @override
  String get kyc_complete_verification => 'إكمال التحقق من الهوية';

  @override
  String get demo_mode_banner => 'أنت في وضع التجربة';

  @override
  String get demo_mode_go_live => 'الانتقال للحساب الحقيقي';

  @override
  String get upgrade_real_account_title => 'الترقية إلى حساب حقيقي';

  @override
  String get upgrade_real_account_msg =>
      'هذه الخاصية تتطلب حساباً حقيقياً مُحققاً. يرجى تحويل حسابك التجريبي إلى حساب حقيقي للوصول إلى جميع الخصائص.';

  @override
  String get upgrade_real_account_now => 'قم بالترقية الآن';

  @override
  String get upgrade_real_account_later => 'ليس الآن';

  @override
  String get delete_warning_full =>
      'تحذير: حذف حسابك نهائي. سيتم مسح جميع بياناتك بشكل دائم ولا يمكن استعادتها. هل أنت متأكد أنك تريد المتابعة؟';

  @override
  String get faceid_enable => 'تفعيل بصمة الوجه';

  @override
  String get faceid_desc => 'استخدم بصمة الوجه للوصول السريع والآمن.';

  @override
  String get app_version => 'الإصدار';

  @override
  String get staging => 'تجريبي';

  @override
  String get production => 'تشغيلي';

  @override
  String get warning => 'تحذير:';

  @override
  String get pi_update_warning =>
      'سيؤدي تحديث المعلومات الشخصية إلى تقييد المعاملات مؤقتًا حتى تتم الموافقة عليها من قبل فريق الدعم لدينا.';

  @override
  String get pending_approval => 'قيد الموافقة';

  @override
  String get uae_num_14 =>
      'أدخل رقم الإمارات العربية المتحدة بدءًا بـ 00971 أو +971';

  @override
  String get saudia_num_14 =>
      'أدخل رقم المملكة العربية السعودية بدءًا بـ 00966 أو +966';

  @override
  String get uae_num_10 => 'أدخل رقم إماراتي مكون من 10 خانات يبدأ بـ 05';

  @override
  String get jordan_num_14 => 'أدخل رقم الأردن بدءًا بـ 00962 أو +962';

  @override
  String get iraq_num_15 => 'أدخل رقم العراق بدءًا بـ 00964 أو +964';

  @override
  String get jordan_iraq_local =>
      'أدخل رقم أردني مكون من 10 خانات (07..) أو رقم عراقي مكون من 11 خانة (07..)';

  @override
  String get phone_format_note => 'يرجى استخدام ‎+9XX أو ‎009XX للتنسيق الدولي';

  @override
  String get update_profile_first =>
      'يرجى تحديث معلومات الملف الشخصي قبل الإرسال.';

  @override
  String get update_required => 'التحديث مطلوب';

  @override
  String get update_message =>
      'هناك نسخة جديدة من التطبيق متاحة. يرجى التحديث للمتابعة.';

  @override
  String get documents => 'المستندات';

  @override
  String get cancel => 'إلغاء';

  @override
  String get verify => 'تحقق';

  @override
  String get residency_document_required => 'مستند الإقامة مطلوب';

  @override
  String get residency_verification_message =>
      'للمتابعة، يرجى إكمال التحقق من مستند الإقامة. هل ترغب في المتابعة الآن؟';

  @override
  String get later => 'لاحقاً';

  @override
  String get proceed => 'متابعة';

  @override
  String get kyc_verification_required => 'التحقق من الهوية مطلوب';

  @override
  String get kyc_verification_message =>
      'للمتابعة، يرجى إكمال عملية التحقق من الهوية. هل ترغب في المتابعة الآن؟';

  @override
  String get no_news_available => 'عذراً! لا توجد أخبار متاحة';

  @override
  String get masked_balance => '*****';

  @override
  String get total_gold => 'إجمالي الذهب';

  @override
  String get total_funds => 'إجمالي الأموال (الدينار العراقي)';

  @override
  String get upgrade_to_real_account => 'الترقية إلى حساب حقيقي';

  @override
  String get upgrade_feature_message =>
      'هذه الميزة تتطلب حسابًا حقيقيًا موثقًا. يرجى تحويل حسابك التجريبي إلى حساب حقيقي للوصول إلى جميع الميزات.';

  @override
  String get not_now => 'ليس الآن';

  @override
  String get upgrade_now => 'الترقية الآن';

  @override
  String get title_not_available => 'العنوان غير متاح';

  @override
  String get description_not_available => 'الوصف غير متاح';

  @override
  String get read_more => 'اقرأ المزيد';

  @override
  String get link_not_available => 'الرابط غير متاح';

  @override
  String get home => 'الرئيسية';

  @override
  String get grams => 'غرامات';

  @override
  String get wallet_empty => 'المحفظة فارغة. أضف أموالاً لشراء الذهب.';

  @override
  String get per_gram_IQD => 'للجرام الدينار العراقي';

  @override
  String get buy_gold => 'شراء ذهب';

  @override
  String get please_enter_valid_amount => 'الرجاء إدخال مبلغ صالح.';

  @override
  String get email_verification_message =>
      'للمتابعة، يرجى التحقق من عنوان بريدك الإلكتروني. هل تريد التحقق الآن؟';

  @override
  String get verify_now => 'تحقق الآن';

  @override
  String get residency_verification_required => 'التحقق من الإقامة مطلوب';

  @override
  String get select_image => 'اختر صورة';

  @override
  String get select_gallery => 'المعرض';

  @override
  String get select_camera => 'الكاميرا';

  @override
  String get insufficient_balance => 'رصيد غير كاف';

  @override
  String get add_funds => 'إضافة أموال';

  @override
  String get insufficient_demo_balance => 'رصيد تجريبي غير كاف';

  @override
  String get demo_balance_message =>
      'رصيدك التجريبي غير كاف. يتم توفير الأموال مرة واحدة فقط ولا يمكن تجديدها. يرجى الاستثمار ضمن رصيدك، أو التبديل إلى حساب حقيقي، أو إنشاء حساب تجريبي جديد.';

  @override
  String get please_add_grams => 'الرجاء إضافة كمية الجرامات.';

  @override
  String get unable_to_fetch_data =>
      'غير قادر على جلب أحدث البيانات. يرجى المحاولة مرة أخرى.';

  @override
  String get data_loading => 'يتم تحميل البيانات. يرجى الانتظار.';

  @override
  String get invalid_amount => 'مبلغ غير صالح. يرجى إدخال قيمة صالحة.';

  @override
  String get please_enter_valid_price => 'الرجاء إدخال سعر صالح.';

  @override
  String get price_limit_message =>
      'أدخل سعرًا أقل من أو يساوي سعر الشراء الحالي.';

  @override
  String get enter_valid_amount => 'أدخل مبلغًا صالحًا للمتابعة.';

  @override
  String get confirmation => 'تأكيد';

  @override
  String get place_order_confirm => ' هل تريد وضع هذا الطلب المعلق الآن؟';

  @override
  String get place_order => 'وضع الطلب';

  @override
  String get confirm_purchase => 'تأكيد الشراء';

  @override
  String get amount => 'الكمية';

  @override
  String get gram => 'غرام';

  @override
  String get idq_currency => 'الدينار العراقي';

  @override
  String get amountVar => 'المبلغ';

  @override
  String get not_available => 'غير متاح';

  @override
  String get email_address => 'البريد الإلكتروني';

  @override
  String get enter_first_name => 'يرجى إدخال اسمك الأول.';

  @override
  String get enter_surname => 'يرجى إدخال اسم العائلة.';

  @override
  String get enter_phone_number => 'يرجى إدخال رقم الهاتف';

  @override
  String get enter_sa_number => 'يرجى إدخال رقم سعودي يبدأ بـ 0096 أو +966.';

  @override
  String get enter_intl_number => 'يرجى استخدام 009XX أو +97XXX للتنسيق الدولي';

  @override
  String get update_profile => 'تحديث الملف الشخصي';

  @override
  String get update => 'تحديث';

  @override
  String get forgot_password_instruction =>
      'أدخل بريدك الإلكتروني أو رقم هاتفك أدناه لاستلام التعليمات لتغيير كلمة المرور الخاصة بك.';

  @override
  String get new_password_different =>
      'يجب أن تكون كلمة المرور الجديدة مختلفة عن كلمة المرور الحالية';

  @override
  String get profile_update_warning =>
      'يرجى تأكيد تحديثات ملفك الشخصي والتأكد من أن جميع المعلومات المدخلة صحيحة قبل المتابعة.';

  @override
  String get profile_verified_warning =>
      'بمجرد التحقق من ملفك الشخصي، سيتم تسجيل خروجك تلقائيًا. هل أنت متأكد أنك تريد المتابعة؟';

  @override
  String get enter_verify_code => 'أدخل رمز التحقق الذي تلقيته على';

  @override
  String get enter_pin => 'يرجى إدخال رمز PIN';

  @override
  String get didnt_receive_code => 'لم تستلم الرمز؟';

  @override
  String get resend => 'إعادة الإرسال';

  @override
  String get verification => 'التحقق';

  @override
  String get enter_verify_code_phone =>
      'أدخل رمز التحقق الذي تلقيته على رقم هاتفك:';

  @override
  String get gram_take_profit => 'جني الأرباح';

  @override
  String get gram_gift_received => 'تم استلام الهدية';

  @override
  String get gram_buy_at_price => 'شراء بأمر السعر';

  @override
  String get gram_invest_money => 'استثمار المال: الدينار العراقي';

  @override
  String get gram_invest_status => 'حالة الاستثمار:';

  @override
  String get gram_date => 'التاريخ:';

  @override
  String get gram_total => 'الإجمالي';

  @override
  String get gram_no_change => 'لا تغيير';

  @override
  String get gram_buy_word => 'شراء';

  @override
  String get gram_sell_word => 'بيع';

  @override
  String get g_Gold => 'غرام ذهب';

  @override
  String get profit_title => 'الربح';

  @override
  String trade_order_message(Object tradeType, Object grams, Object price) {
    return '$tradeType $grams غرام من الذهب بسعر $price';
  }

  @override
  String get trade_sell => 'بيع';

  @override
  String get deal_bought_at_price => 'تم الشراء بسعر';

  @override
  String get deal_edit_price => 'تعديل السعر';

  @override
  String get deal_price_per_gram => 'السعر لكل غرام (الدينار العراقي)';

  @override
  String get deal_gram_price => 'سعر الغرام';

  @override
  String get deal_enter_amount_IQD => 'يرجى إدخال المبلغ بالالدينار العراقي';

  @override
  String get deal_valid_number => 'يرجى إدخال رقم صالح';

  @override
  String get deal_zero_value_validation => 'يرجى إدخال مبلغ أكبر من الصفر';

  @override
  String get deal_edit_gram => 'تعديل كمية الغرام';

  @override
  String get deal_gram_amount => 'كمية الغرام';

  @override
  String get deal_update_order => 'تحديث الطلب';

  @override
  String get deal_enter_valid_gram => 'يرجى إدخال كمية غرام صالحة';

  @override
  String get deal_sell_greater_than_bought =>
      'يرجى إدخال سعر بيع أكبر من سعر الشراء (الدينار العراقي)';

  @override
  String get deal_pending_sell_greater_with_zero_buying_than_current_sell =>
      'يرجى إدخال سعر بيع أكبر من أو يساوي سعر البيع الحالي (الدينار العراقي)';

  @override
  String get deal_buy_price_less =>
      'يرجى إدخال سعر شراء أقل من سعر الشراء الحالي (الدينار العراقي)';

  @override
  String get deal_sure_confirm => 'هل أنت متأكد أنك تريد تحديث هذا الطلب؟';

  @override
  String get deal_cancel_order => 'هل أنت متأكد أنك تريد إلغاء هذا الطلب؟';

  @override
  String get deal_cance_title => 'إلغاء الطلب';

  @override
  String get deal_manage_deal => 'إدارة الصفقة';

  @override
  String get deal_close => 'لا يمكنك إغلاق هذه الصفقة بخسارة';

  @override
  String get deal_amount_must_less => 'يجب أن يكون المبلغ أقل من أو يساوي';

  @override
  String get is_below_buy => 'أقل من سعر الشراء الخاص بك (الدينار العراقي';

  @override
  String get deal_confirm_loss => 'تأكيد الخسارة';

  @override
  String get deal_confirm_deal_closure => 'تأكيد إغلاق الصفقة';

  @override
  String get deal_about_to_close =>
      'أنت على وشك إغلاق هذه الصفقة بخسارة. هل أنت متأكد؟';

  @override
  String get deal_sure_want_to_close => 'هل أنت متأكد أنك تريد إغلاق';

  @override
  String get deal_g_of_deal => 'غ من هذه الصفقة؟';

  @override
  String get deal_close_anyway => 'إغلاق على أي حال';

  @override
  String get deal_enter_valid_nmbr => 'يرجى إدخال رقم صالح';

  @override
  String get confirm => 'تأكيد';

  @override
  String get finger_print_warning => 'فشل التحقق من بصمة الإصبع.';

  @override
  String get invalid_otp => 'رمز التحقق غير صالح: يرجى إدخال رمز صالح';

  @override
  String get user_firstName => 'السيد زيد';

  @override
  String get user_lastName => 'جابر';

  @override
  String get upgrade_to_real_message =>
      'يرجى ملاحظة أن الترقية إلى حساب حقيقي ستؤدي إلى حذف بيانات حسابك التجريبي الحالي.';

  @override
  String get update_Account => 'تحديث الحساب';

  @override
  String get active_alerts => 'التنبيهات النشطة';

  @override
  String get no_active_alerts => 'لا توجد تنبيهات نشطة';

  @override
  String get no_active_alert_at_moment => ' لا توجد أي إشعارات فعّالة حالياً';

  @override
  String get create_new_alert => 'إنشاء تنبيه جديد';

  @override
  String get alert_selling => 'تنبيه بيع';

  @override
  String get alert_buying => 'تنبيه شراء';

  @override
  String get alert_bar => 'التنبيهات';

  @override
  String get active_title => 'نشط';

  @override
  String get active_difference => 'الفرق';

  @override
  String get please_enter_target_price => 'يرجى إدخال السعر المستهدف';

  @override
  String get unable_to_fetch_current_prices => 'تعذر جلب الأسعار الحالية';

  @override
  String get buy_alert_below_current_price =>
      'يجب أن يكون سعر تنبيه الشراء أقل من سعر الشراء الحالي';

  @override
  String get sell_alert_above_current_price =>
      'يجب أن يكون سعر تنبيه البيع أعلى من سعر البيع الحالي';

  @override
  String get add_alert => 'إضافة تنبيه';

  @override
  String get alert_type => 'نوع التنبيه';

  @override
  String get side => 'الجانب';

  @override
  String get select_script => 'اختر السهم';

  @override
  String get target_price => 'السعر المستهدف';

  @override
  String get enter_price => 'أدخل السعر';

  @override
  String get must_be_below => 'يجب أن يكون أقل من';

  @override
  String get must_be_above => 'يجب أن يكون أعلى من';

  @override
  String get loading_current_prices => 'جاري تحميل الأسعار الحالية...';

  @override
  String get submit => 'إرسال';

  @override
  String get one_gm_price => 'سعر 1 جرام';

  @override
  String get price_alert => 'تنبيه السعر';

  @override
  String get price_below => 'أدنى من';

  @override
  String get price_above => 'أعلى من';

  @override
  String get order_list => 'قائمة الطلبات';

  @override
  String get alert_title => 'تنبيه';

  @override
  String get no_data_to_show => 'لا توجد بيانات لعرضها';

  @override
  String get no_order_available => 'لا يوجد طلب متاح';

  @override
  String get are_you_sure_want_to_delete => 'هل أنت متأكد أنك تريد الحذف؟';

  @override
  String get idq => 'الدينار العراقي';

  @override
  String get at => 'في';

  @override
  String get g_ => 'غرام';

  @override
  String get rejected => 'مرفوض';

  @override
  String get approved => 'مقبول';

  @override
  String get comment_here => 'اكتب تعليقك هنا';

  @override
  String get some_error_occurred => 'حدث خطأ ما';

  @override
  String get buy_now => 'اشترِ الآن';

  @override
  String get verify_email_message =>
      'للمتابعة، يرجى التحقق من عنوان بريدك الإلكتروني. هل ترغب في التحقق الآن؟';

  @override
  String get residency_document_message =>
      'للمتابعة، يرجى إكمال التحقق من مستند الإقامة. هل ترغب في المتابعة الآن؟';

  @override
  String get product_code => 'رمز المنتج';

  @override
  String get weight_category => 'فئة الوزن';

  @override
  String get in_store_collection => 'الاستلام من المتجر';

  @override
  String get delivery_available => 'التوصيل متاح';

  @override
  String get you_already_have => 'لديك بالفعل';

  @override
  String get which_meet_or_exceed => 'جم، وهو ما يساوي أو يتجاوز هدفك البالغ';

  @override
  String get shipping_and_delivery => 'الشحن والتوصيل';

  @override
  String get in_store_collection_detail =>
      'In-store pickup is available for all products. Pickups are available Monday to Friday, 11:00 AM to 6:00 PM (Timezone, Gulf Standard Time). An email confirmation will be sent to you when your order is ready for pickup.';

  @override
  String get shipping_fees => 'رسوم الشحن';

  @override
  String get shipping_fees_detail =>
      'نقدم خدمات الشحن بالأسعار التالية:\nالتوصيل في اليوم التالي ابتداءً من';

  @override
  String get delivery_identified_person => 'التسليم لشخص محدد:';

  @override
  String get delivery_identified_person_detail =>
      'يجب على العميل إدخال التفاصيل الصحيحة لاسم المستلم كما هو مذكور في بطاقة الهوية الحكومية، مع العنوان الكامل، ومعلم قريب، والرمز البريدي، ورقم الاتصال لتسهيل عملية التسليم.';

  @override
  String get delivery_location => 'موقع التسليم:';

  @override
  String get delivery_location_detail =>
      'يمكن تسليم الطلبات إلى المواقع السكنية والتجارية فقط.';

  @override
  String get filter_all => 'الكل';

  @override
  String get monday_to_friday =>
      ' الاثنين إلى الجمعة، من 11:00 صباحًا إلى 6:00 مساءً (التوقيت: توقيت الخليج القياسي) سيكون هناك تكلفة';

  @override
  String get once_order_ready =>
      'بمجرد أن يكون طلبك جاهزًا، سنرسل لك بريدًا إلكترونيًا يحتوي على معلومات التتبع الخاصة بك.';

  @override
  String get no_metal_statement_title => 'أدخل رمز التحقق';

  @override
  String get no_metal_statement_description =>
      'يرجى إنشاء كشف معادن جديد أو المحاولة مرة أخرى لاحقًا';

  @override
  String get no_data_title => 'لا توجد بيانات لعرضها';

  @override
  String get error_description => 'حدث خطأ. يرجى المحاولة مرة أخرى لاحقًا.';

  @override
  String get all => 'الكل';

  @override
  String get customer_have_enter =>
      'يجب على العميل إدخال البيانات الصحيحة للمستلم \nاسم المستفيد (كما هو مذكور في بطاقة الهوية الخاصة به والمعتمدة من الحكومة) مع العنوان الكامل، ومعلم قريب، والرمز البريدي، ورقم الاتصال لضمان توصيل سلس.';

  @override
  String get oops_not_found => 'عذرًا! لم يتم العثور على شيء';

  @override
  String get no_money_statement_description =>
      'يرجى إنشاء كشف أموال جديد أو المحاولة مرة أخرى لاحقًا';

  @override
  String get order_can_be_delivered =>
      'يمكن تسليم الطلبات إلى المواقع السكنية والتجارية فقط.';

  @override
  String get na => 'غير متوفر';

  @override
  String get enter_valid_phone => 'أدخل رقم هاتف صالح';

  @override
  String get weight_1_gram => '1 جرام';

  @override
  String get weight_2_grams => '2 جرام';

  @override
  String get weight_2_5_grams => '2.5 جرام';

  @override
  String get weight_5_grams => '5 جرام';

  @override
  String get weight_10_grams => '10 جرام';

  @override
  String get weight_20_grams => '20 جرام';

  @override
  String get weight_half_ounce => 'نصف أونصة';

  @override
  String get weight_1_ounce => '1 أونصة';

  @override
  String get weight_50_grams => '50 جرام';

  @override
  String get weight_100_grams => '100 جرام';

  @override
  String get weight_10_tola => '10 توله';

  @override
  String get weight_125_grams => '250 جرام';

  @override
  String get weight_250_grams => '250 جرام';

  @override
  String get weight_500_grams => '500 جرام';

  @override
  String get weight_1_kilogram => '1 كيلوجرام';

  @override
  String get apply_filters_description =>
      'قم بتطبيق الفلاتر لعرض المنتجات المطلوبة بسرعة.';

  @override
  String get casting => 'الصب';

  @override
  String get clear_filters => 'مسح الفلاتر';

  @override
  String get apply_filters => 'تطبيق الفلاتر';

  @override
  String get minting => 'السكّ';

  @override
  String get filters => 'الفلاتر';

  @override
  String get delete_alert => 'حذف التنبيه';

  @override
  String get delete_alert_message => 'هل أنت متأكد أنك تريد حذف هذا التنبيه؟';

  @override
  String get delete => 'حذف';

  @override
  String get update_alert => 'تحديث التنبيه';

  @override
  String get buy => 'شراء';

  @override
  String get less => 'أقل';

  @override
  String get more => 'أكثر';

  @override
  String get one_gram_price => 'سعر 1 غرام';

  @override
  String get sell => 'بيع';

  @override
  String get previous_bank_accounts => 'الحسابات البنكية السابقة';

  @override
  String get tap_any_account_to_fill_details =>
      'اضغط على أي حساب لملء التفاصيل تلقائيًا';

  @override
  String get tap_to_use => 'اضغط للاستخدام';

  @override
  String get bank_fee_notice =>
      'سيتم تطبيق رسوم بنكية قدرها 25 الدينار العراقيًا إماراتيًا بالإضافة إلى ضريبة القيمة المضافة.';

  @override
  String get bank_name => 'اسم البنك';

  @override
  String get canceled => 'ألغيت';

  @override
  String get image_upload_successfull => 'تم تحميل الصورة بنجاح';

  @override
  String get copied_to_clipboard => 'تم النسخ إلى الحافظة';

  @override
  String get saved_to_clipboard => 'تم الحفظ في الحافظة';

  @override
  String get shufti_pro_verification_failed => 'فشل التحقق، حاول مرة أخرى.';

  @override
  String get shufti_user_auth_issue => 'خطأ في مصادقة المستخدم، حاول مرة أخرى.';

  @override
  String get kyc_verification_failed =>
      'فشل التحقق من KYC، يرجى المحاولة مرة أخرى.';

  @override
  String get kyc_error => 'خطأ في التحقق، حاول مرة أخرى.';

  @override
  String get want_to_change_email => 'هل تريد تغيير البريد الإلكتروني؟';

  @override
  String get submit_kyc_error => 'خطأ في إرسال بيانات KYC:';

  @override
  String get no_saved_credentials => 'لم يتم العثور على بيانات اعتماد محفوظة.';

  @override
  String get exit_app => 'الخروج من التطبيق';

  @override
  String get visit_website => 'زيارة الموقع';

  @override
  String get open_setting => 'فتح الإعدادات';

  @override
  String get please_check_internet => 'يرجى التحقق من اتصال الإنترنت';

  @override
  String get no_internet => 'لا يوجد اتصال بالإنترنت';

  @override
  String get maintainance_description =>
      'سيڤ إن جولد تخضع حاليًا لترقية نظام مجدولة لتعزيز الأمان والاستقرار وأداء تداول الذهب في الوقت الفعلي';

  @override
  String get server_under_maintainance => 'الخادم قيد الصيانة';

  @override
  String get swift_code => 'رمز السويفت';

  @override
  String get account_detail => 'تفاصيل الحساب';

  @override
  String get email_update_des =>
      'سيتم تسجيل خروجك بمجرد تحديث بريدك الإلكتروني بنجاح';

  @override
  String get entered_wrong_otp => 'يرجى إدخال رمز التحقق الصحيح';

  @override
  String get scan_finger_print => 'امسح بصمة إصبعك لتحديث بريدك الإلكتروني';

  @override
  String get plz_update_email => 'يرجى تحديث بريدك الإلكتروني';

  @override
  String get are_u_sure_to_update_email =>
      'هل أنت متأكد أنك تريد تحديث البريد الإلكتروني إلى';

  @override
  String get change_email => 'تغيير البريد الإلكتروني';

  @override
  String get temporary_credit_title => 'رصيد مؤقت مفعل';

  @override
  String get temporary_credit_message =>
      'لديك حالياً رصيد مؤقت. لا يمكنك إرسال هدية في الوقت الحالي. يرجى التواصل مع فريق الدعم للحصول على المساعدة.';

  @override
  String get temporary_credit_contact_support => 'اتصل بالدعم';

  @override
  String get temperory_credit_detect =>
      'لديك حالياً رصيد ائتمان مؤقت. لا يمكنك السحب في الوقت الحالي. يرجى التواصل مع فريق الدعم للحصول على المساعدة.';

  @override
  String get temperory_credit_detect_esouq =>
      'لديك حالياً رصيد ائتمان مؤقت. لا يمكنك الشراء في الوقت الحالي. يرجى التواصل مع فريق الدعم للحصول على المساعدة.';

  @override
  String get temporary_freezed => 'تم إيقاف الحساب مؤقتًا';

  @override
  String get temporary_freezed_account_desc =>
      'تم إيقاف حسابك مؤقتًا. لاستعادة الوصول، يرجى التواصل مع فريق الدعم للحصول على المساعدة.';

  @override
  String get doc_mismatch =>
      'لغة اسم المستند واسم الملف الشخصي غير متطابقة. يرجى تحميل هوية مطابقة.';

  @override
  String get nam_mismatch => 'عدم تطابق في الأسماء';

  @override
  String get no_withdraw => 'لا توجد طلبات سحب في الوقت الحالي';

  @override
  String get trade_gold => 'تداول الذهب';

  @override
  String get trade_gram => '/ غرام';

  @override
  String get current_market_price => 'سعر السوق الحالي';

  @override
  String get buying_at => 'الشراء عند';

  @override
  String get selling_at => 'البيع عند';

  @override
  String get error_loading_prices => 'تعذر تحميل الأسعار';

  @override
  String price_iqd_per_gram(String price) {
    return '$price د.ع / غرام';
  }

  @override
  String ounce_price_iqd(String price) {
    return 'الأونصة: $price د.ع';
  }

  @override
  String high_price_badge(String price) {
    return 'أعلى $price';
  }

  @override
  String low_price_badge(String price) {
    return 'أدنى $price';
  }

  @override
  String get gram_unit_plural => 'غرام';

  @override
  String get current_trade_deals => 'صفقات التداول الحالية';

  @override
  String get gram_no_filled_deals =>
      'لا توجد لديك صفقات مفتوحة أو منفذة في الوقت الحالي.';

  @override
  String get side_menu_esouq_subtitle => 'تسوّق عبر الإنترنت لأفضل العروض';

  @override
  String get side_menu_orders_subtitle => 'تتبع طلباتك وإدارتها';

  @override
  String get side_menu_gift_subtitle => 'أرسل هدية لصديق';

  @override
  String get side_menu_alerts_subtitle =>
      'احصل على إشعار عندما يصل سعر الذهب إلى هدفك';

  @override
  String get side_menu_support_subtitle => 'تواصل مع فريق الدعم';

  @override
  String get side_menu_settings_subtitle => 'إدارة حسابك وتفضيلات التطبيق';

  @override
  String get side_menu_logout_subtitle => 'تسجيل الخروج من حسابك';

  @override
  String deal_sell_greater_than_current_sell_price(String price) {
    return 'يرجى إدخال سعر بيع أعلى من سعر البيع الحالي ($price د.ع).';
  }

  @override
  String get about_to_save_profit => 'أنت على وشك حفظ الربح';

  @override
  String get about_to_take_profit_message => 'أنت على وشك جني الربح';

  @override
  String get something_went_wrong_try_again =>
      'حدث خطأ ما. يرجى المحاولة مرة أخرى.';

  @override
  String get quick_action_withdraw => 'سحب';

  @override
  String get could_not_open_link => 'تعذر فتح الرابط';

  @override
  String get home_wallet_funds_label => 'الأموال';

  @override
  String get history_no_metal => 'لا يوجد لديك سجل معادن في الوقت الحالي.';

  @override
  String get history_no_money => 'لا يوجد لديك سجل أموال في الوقت الحالي.';

  @override
  String get see_details => 'عرض التفاصيل';

  @override
  String get see_less => 'إخفاء التفاصيل';

  @override
  String get screen_details_title => 'التفاصيل';

  @override
  String get triggered_by => 'وقت التنفيذ';

  @override
  String get transaction_details_header => 'تفاصيل المعاملة';

  @override
  String get metal_opened_at => 'فُتح عند';

  @override
  String get metal_closed_at => 'أُغلق عند';

  @override
  String get status_closed => 'مغلق';

  @override
  String get shape_sub_type => 'نوع الشكل الفرعي';

  @override
  String get no_weight_available => 'لا توجد خيارات وزن متاحة';

  @override
  String get bar => 'سبيكة';

  @override
  String get coin => 'عملة';

  @override
  String get buy_gold_grams_subtitle => 'أدخل كمية الذهب بالغرامات للتداول';

  @override
  String get grams_unit_lowercase => 'غرام';

  @override
  String get grams_plural_lowercase => 'غرامات';

  @override
  String buy_gold_approx_total(String amount) {
    return '≈ $amount د.ع';
  }

  @override
  String get invest_target_price_per_gram => 'السعر المستهدف (للغرام)';

  @override
  String buy_order_executes_at_iqd(String price) {
    return 'يُنفَّذ طلبك عندما يصل السعر إلى $price د.ع';
  }

  @override
  String get trade_at_market_price => 'التداول بسعر السوق';

  @override
  String get invest_target_price_menu => 'سعر مستهدف';

  @override
  String get invest_market_price_short => 'سعر السوق';

  @override
  String get inves_market_order => 'أمر السوق';

  @override
  String get target_price_hint_example => 'د.ع 170,000.00';

  @override
  String get error_loading_price => 'تعذر تحميل السعر';

  @override
  String get plz_enter_target_price => 'يرجى إدخال السعر المستهدف';

  @override
  String get target_buying_price_lower =>
      'يجب أن يكون سعر الشراء المستهدف أقل من سعر الشراء الحالي';

  @override
  String get target_selling_price =>
      'يجب أن يكون سعر البيع المستهدف أعلى من سعر البيع الحالي';

  @override
  String get trade_confirm_dialog_title => 'تأكيد الصفقة';

  @override
  String get trade_confirm_dialog_subtitle => 'راجع تفاصيل طلبك';

  @override
  String get trade_confirm_dialog_button => 'تأكيد الصفقة';

  @override
  String get trade_confirm_sale_title => 'تأكيد البيع';

  @override
  String get trade_row_target_price => 'السعر المستهدف';

  @override
  String get trade_row_est_total => 'التكلفة الإجمالية التقديرية';

  @override
  String trade_confirm_limit_body(String targetPrice) {
    return 'يُنفَّذ طلبك عندما يصل سعر الذهب إلى $targetPrice د.ع للغرام. سنُعلمك عند حدوث ذلك.';
  }

  @override
  String get order_placed_title => 'تم تنفيذ الطلب!';

  @override
  String get limit_order_title => 'أمر محدد';

  @override
  String get limit_order_des =>
      'تم تقديم الأمر المحدد الخاص بك وسيتم\nتنفيذه عند الوصول إلى السعر المستهدف.';

  @override
  String get limit_order_success => 'تم تقديم الطلب بنجاح.';

  @override
  String get limit_date_time => 'التاريخ والوقت';

  @override
  String get limit_trade_type => 'نوع العملية';

  @override
  String get limit_amount => 'المبلغ';

  @override
  String get execution_Price => 'سعر التنفيذ';

  @override
  String get gmt_time => 'الإجمالي';

  @override
  String get will_notify => 'سنقوم بإشعارك عند تنفيذ طلبك';

  @override
  String get return_home => 'العودة إلى الصفحة الرئيسية';

  @override
  String get open_real_account => 'فتح حساب حقيقي';

  @override
  String get register_for_free_demo => 'التسجيل للحصول على حساب تجريبي مجاني';

  @override
  String get kyc_done => 'تم';

  @override
  String get kyc_title_contact => 'معلومات الاتصال';

  @override
  String get kyc_full_name => 'الاسم الكامل';

  @override
  String get kyc_personal_detail => 'البيانات الشخصية';

  @override
  String get kyc_national_id => 'الهوية الوطنية';

  @override
  String get kyc_income => 'الدخل والعمل';

  @override
  String get kyc_address => 'العنوان';

  @override
  String get kyc_compliance => 'الامتثال';

  @override
  String get kyc_foreignres => 'الإقامة الأجنبية';

  @override
  String get kyc_foreigncit => 'الجنسية الأجنبية';

  @override
  String get kyc_phone_verified => 'تم التحقق ✓';

  @override
  String get kyc_verify_number => 'التحقق من الرقم';

  @override
  String get kyc_email_verified => 'تم التحقق ✓';

  @override
  String get kyc_verify_email => 'التحقق من البريد الإلكتروني';

  @override
  String get kyc_update_contact_detail =>
      'في حال تغيير رقم الهاتف أو البريد الإلكتروني، يجب إعادة التحقق منهما قبل إرسال الطلب.';

  @override
  String get kyc_father_name => 'اسم الأب';

  @override
  String get kyc_grand_father_name => 'اسم الجد';

  @override
  String get kyc_surname => 'اللقب';

  @override
  String get kyc_mother_name => 'اسم الأم';

  @override
  String get kyc_gender => 'الجنس';

  @override
  String get kyc_country_of_birth => 'بلد الميلاد';

  @override
  String get kyc_place_birth => 'مكان الميلاد';

  @override
  String get kyc_personal_number => 'الرقم الشخصي';

  @override
  String get kyc_id_number => 'رقم الهوية (الرقم التسلسلي للبطاقة)';

  @override
  String get kyc_place_of_issue => 'مكان الإصدار';

  @override
  String get kyc_date_of_issue => 'تاريخ الإصدار';

  @override
  String get kyc_date_of_expiry => 'تاريخ الانتهاء';

  @override
  String get kyc_passport_number => 'رقم جواز السفر';

  @override
  String get kyc_education_level => 'المستوى التعليمي';

  @override
  String get kyc_economic_sector => 'القطاع الاقتصادي';

  @override
  String get kyc_total_monthly_income => 'إجمالي الدخل الشهري (دينار عراقي)';

  @override
  String get kyc_employer_address => 'عنوان جهة العمل';

  @override
  String get kyc_governorate => 'المحافظة';

  @override
  String get kyc_district => 'القضاء';

  @override
  String get kyc_city_town => 'المدينة / البلدة';

  @override
  String get kyc_mahalla => 'المحلة';

  @override
  String get kyc_street => 'الشارع';

  @override
  String get kyc_house_no => 'رقم الدار';

  @override
  String get kyc_nearest_landmark_ar => 'أقرب معلم (بالعربية)';

  @override
  String get kyc_neares_landmart_eng => 'أقرب معلم (بالإنجليزية)';

  @override
  String get kyc_are_u_us_person => 'هل أنت شخص أمريكي؟';

  @override
  String get kyc_us => 'الرقم الضريبي الأمريكي / رقم الضمان الاجتماعي';

  @override
  String get kyc_us_address => 'العنوان في الولايات المتحدة';

  @override
  String get kyc_do_you_fall_into_pep =>
      'هل تندرج ضمن أي فئة من فئات الأشخاص المعرضين سياسياً (PEP)؟';

  @override
  String get kyc_position_held =>
      'المنصب المشغول / صلة القرابة بالشخص المعرض سياسياً';

  @override
  String get kyc_from_date => 'من (شهر/سنة)';

  @override
  String get kyc_from_date_hint => 'من (شهر/سنة)';

  @override
  String get kyc_to_date => 'إلى (شهر/سنة)';

  @override
  String get kyc_to_date_hint => 'إلى (شهر/سنة)';

  @override
  String get kyc_permission_to_reside_outside_iraq =>
      'هل لديك تصريح للإقامة خارج العراق؟';

  @override
  String get kyc_citizenship => 'هل تحمل جنسية دولة أخرى؟';

  @override
  String get kyc_we_will_send_otp_on_phone =>
      'سنرسل رمز تحقق لمرة واحدة إلى رقم هاتفك عبر واتساب.';

  @override
  String get kyc_we_will_send_otp_on_email =>
      'سنرسل رمز تحقق لمرة واحدة إلى بريدك الإلكتروني.';

  @override
  String get kyc_didnt_recieve_code => 'لم تستلم الرمز؟';

  @override
  String get kyc_resend_in => 'إعادة الإرسال خلال';

  @override
  String get kyc_resend_code => 'إعادة إرسال الرمز';

  @override
  String get kyc_sending => 'جارٍ الإرسال…';

  @override
  String get kyc_send_code => 'إرسال الرمز';

  @override
  String get kyc_before_u_begin => 'قبل أن تبدأ';

  @override
  String get kyc_have_documents_title => 'جهّز المستندات التالية';

  @override
  String get kyc_lede_doc =>
      'جميع المستندات الثلاثة التالية مطلوبة لإكمال عملية التسجيل. يرجى تجهيزها قبل المتابعة.';

  @override
  String get kyc_national_card_title => 'البطاقة الوطنية';

  @override
  String get kyc_national_card_subtitle =>
      'الوجه الأمامي والخلفي. سيكون كلا رقمي البطاقة مطلوبين.';

  @override
  String get kyc_residence_card_title => 'بطاقة السكن';

  @override
  String get kyc_residence_card_subtitle => 'الوجه الأمامي والخلفي.';

  @override
  String get kyc_passort_title => 'جواز السفر (إن وجد)';

  @override
  String get kyc_passport_subtitle =>
      'يُستخدم لكتابة اسمك باللغة الإنجليزية. يمكنك المتابعة بدونه.';

  @override
  String get kyc_you_will_need => 'ستحتاج أيضاً إلى';

  @override
  String get kyc_roughly_six => 'حوالي ست (6) دقائق لإكمال النموذج.';

  @override
  String get kyc_additional_documents =>
      'قد تكون هناك حاجة إلى مستندات إضافية إذا كنت تحمل إقامة أو جنسية خارج العراق.';

  @override
  String get kyc_section_1 => 'القسم 1 · الغرض والنطاق';

  @override
  String get kyc_before_we_begin => 'قبل أن نبدأ';

  @override
  String get kyc_number_1 => '1.1';

  @override
  String get kyc_about_bbh_bold => 'نبذة عن بيت بغداد للسبائك.';

  @override
  String get kyc_about_bbh_body =>
      'بيت بغداد للسبائك (BBH) تاجر مرخص للمعادن والأحجار الكريمة، مسجل في العراق تحت رقم السجل التجاري 17240، وله أربعة (4) فروع في بغداد وفرع واحد (1) في النجف.';

  @override
  String get kyc_number_2 => '1.2';

  @override
  String get kyc_number_2_bold => 'ما الذي نجمعه.';

  @override
  String get kyc_number_2_body =>
      'تتضمن هذه العملية جمع بيانات التعريف الخاصة بك، والملف الاقتصادي، وإقرارات الامتثال اللازمة لفتح حساب الذهب الخاص بك لدى BBH.';

  @override
  String get kyc_number_3 => '1.3';

  @override
  String get kyc_number_3_bold => 'ما الذي نحتفظ به.';

  @override
  String get kyc_number_3_body =>
      'يتم الاحتفاظ بجميع السجلات بشكل آمن لدى BBH للفترة المطلوبة بموجب القانون العراقي، على ألا تقل عن سبع (7) سنوات من تاريخ إغلاق الحساب أو آخر معاملة.';

  @override
  String get kyc_purpose => 'تأكيد الغرض';

  @override
  String get kyc_purpose_des =>
      'لقد تم إبلاغي بما ورد أعلاه وأرغب في متابعة إجراءات التسجيل لدى BBH.';

  @override
  String trade_confirm_market_body(String price) {
    return 'يُنفَّذ تداولك فورًا بسعر السوق الحالي البالغ $price د.ع. تأكد من كفاية رصيدك.';
  }
}
