import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_client_sse/constants/sse_request_type_enum.dart';
import 'package:flutter_client_sse/flutter_client_sse.dart';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';
import 'package:logger/logger.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:saveingold_fzco/core/enums/loading_state.dart';
import 'package:saveingold_fzco/core/theme/const_toasts.dart';
import 'package:saveingold_fzco/data/data_sources/local_database/local_database.dart';
import 'package:saveingold_fzco/data/models/ErrorResponse.dart';
import 'package:saveingold_fzco/data/models/SuccessResponse.dart';

import '../../../../core/common_service.dart';
import '../../../../data/data_sources/network_sources/api_url.dart';
import '../../../../data/models/SSEGetPriceResponse.dart';
import '../../../../data/models/gold_price_model/CurrentGoldPriceModel.dart';
import '../../../../main.dart';
import '../../../feature_injection.dart';
import '../../../widgets/pop_up_widget.dart';

part 'sse_gold_price_provider.g.dart';

class SSEGoldPriceState {
  final CurrentGoldPriceModel currentGoldPriceModel;
  final SSEGetGoldPriceResponse getGoldPriceResponse;
  final ErrorResponse errorResponse;
  final SuccessResponse successResponse;
  final LoadingState loadingState;

  final double oneOunceDollarSellingPrice;
  final double oneOunceDollarBuyingPrice;
  final double lastLowSellingPrice;
  final double lastHighBuyingPrice;

  final double oneGramBuyingPriceInIQD;
  final double oneGramSellingPriceInIQD;

  final bool isLoading;

  SSEGoldPriceState({
    CurrentGoldPriceModel? currentGoldPriceModel,
    SSEGetGoldPriceResponse? getGoldPriceResponse,
    ErrorResponse? errorResponse,
    SuccessResponse? successResponse,
    this.oneGramBuyingPriceInIQD = 0.0,
    this.oneGramSellingPriceInIQD = 0.0,
    this.oneOunceDollarSellingPrice = 0.0,
    this.oneOunceDollarBuyingPrice = 0.0,
    this.lastLowSellingPrice = 0.0,
    this.lastHighBuyingPrice = 0.0,
    this.loadingState = LoadingState.loading,
    this.isLoading = false,
  }) : currentGoldPriceModel = currentGoldPriceModel ?? CurrentGoldPriceModel(),
       getGoldPriceResponse = getGoldPriceResponse ?? SSEGetGoldPriceResponse(),
       errorResponse = errorResponse ?? ErrorResponse(),
       successResponse = successResponse ?? SuccessResponse();
}

/// ---------------------------------------------------------------------------
/// GLOBAL SSE CONTROL
/// ---------------------------------------------------------------------------

StreamSubscription<SSEModel>? _subscription;
Timer? _reconnectTimer;
Timer? _heartbeatTimer;

DateTime _lastEventTime = DateTime.now();
bool _isConnecting = false;

/// ---------------------------------------------------------------------------
/// RIVERPOD PROVIDER
/// ---------------------------------------------------------------------------

@riverpod
Stream<SSEGoldPriceState> goldPrice(GoldPriceRef ref) {
  final controller = StreamController<SSEGoldPriceState>();
  _startSSE(
    onData: (state) {
      if (!controller.isClosed) {
        controller.add(state);
      }
    },
    onError: (error) {
      if (!controller.isClosed) {
        controller.addError(error);
      }
    },
  );

  // _startSSE(
  //   onData: controller.add,
  //   onError: (error) => controller.addError(error),
  // );

  ref.onDispose(() {
    stopSSE();
    controller.close();
  });

  return controller.stream;
}

/// ---------------------------------------------------------------------------
/// SSE START
/// ---------------------------------------------------------------------------
bool maxDurationPopupShown = false;
Future<void> _startSSE({
  required void Function(SSEGoldPriceState) onData,
  required void Function(dynamic error)? onError,
}) async {
  if (_isConnecting) return;
  _isConnecting = true;
  dynamic responseData;
  try {
    final hasInternet = await InternetConnection().hasInternetAccess;
    if (!hasInternet) {
      Toasts.getErrorToast(text: "No Internet Connection");
      _scheduleReconnect(onData, onError);
      return;
    }

    final token = await LocalDatabase.instance.getLoginToken();

    final headers = {
      "Authorization": "Bearer $token",
      "Accept": "text/event-stream",
      "Cache-Control": "no-cache",
      "Connection": "keep-alive",
    };

    const IQD = 1309.550; // Conversion rate from USD to IQD
    const ounce = 31.10347; // Grams in a troy ounce

    double lastSelling = 0.0;
    double lastBuying = 0.0;
    double lastLow = 0.0;
    double lastHigh = 0.0;
    Future<void> showMaxDurationPopup() async {
      final context = navigatorKey.currentContext;
      if (context == null) return;

      await genericPopUpWidget(
        isLoadingState: false,
        context: context,
        heading: "Warning",
        subtitle: "Your session has expired due to maximum duration.",
        yesButtonTitle: "OK",
        onYesPress: () async {
          Navigator.pop(context);
        },
        onNoPress: () {},
      );
    }

    _subscription =
        SSEClient.subscribeToSSE(
          method: SSERequestType.GET,
          url: ApiEndpoints.getGoldPriceApiUrl,
          header: headers,
        ).listen(
          (event) {
            final raw = event.data;
            if (raw == null || raw.trim().isEmpty) {
              return;
            }
            _lastEventTime = DateTime.now();

            try {
              // final decoded = jsonDecode(event.data ?? "{}");
              // responseData = jsonDecode(event.data ?? "{}");

              // /// 🔴 HANDLE MAX DURATION EVENT
              // if (decoded is Map &&
              //     decoded["reason"] == "max_duration_reached") {
              //   if (!maxDurationPopupShown) {
              //     maxDurationPopupShown = true;

              // stopSSE();

              //     showMaxDurationPopup();
              //   }
              //   return;
              // }
              // if (decoded is! List) {
              //   return;
              // }
              final List<dynamic> jsonList = jsonDecode(event.data ?? "[]");

              final response = SSEGetGoldPriceResponse.fromJson(jsonList);

              if (response.prices!.isEmpty) return;

              double sellingPx = 0.0;
              double buyingPx = 0.0;
              double lowPx = 0.0;
              double highPx = 0.0;

              for (final p in response.prices!.reversed) {
                if (p.mDEntryType == "Bid") {
                  sellingPx = (p.mDSellingPx ?? 0).toDouble();
                  lowPx = (p.lastLowSellingPrice ?? 0).toDouble();
                }
                if (p.mDEntryType == "Offer") {
                  buyingPx = (p.mDBuyingPx ?? 0).toDouble();
                  highPx = (p.lastHighBuyingPrice ?? 0).toDouble();
                }
                if (sellingPx != 0 && buyingPx != 0) break;
              }

              sellingPx = sellingPx == 0 ? lastSelling : sellingPx;
              buyingPx = buyingPx == 0 ? lastBuying : buyingPx;
              lowPx = lowPx == 0 ? lastLow : lowPx;
              highPx = highPx == 0 ? lastHigh : highPx;

              lastSelling = sellingPx;
              lastBuying = buyingPx;
              lastLow = lowPx;
              lastHigh = highPx;

              final state = SSEGoldPriceState(
                oneOunceDollarSellingPrice: sellingPx,
                oneOunceDollarBuyingPrice: buyingPx,
                lastLowSellingPrice: CommonService.getOneGramPriceInIQD(
                  ounceDollarPrice: lowPx,
                  dirham: IQD,
                  ounce: ounce,
                ),
                lastHighBuyingPrice: CommonService.getOneGramPriceInIQD(
                  ounceDollarPrice: highPx,
                  dirham: IQD,
                  ounce: ounce,
                ),
                oneGramSellingPriceInIQD: CommonService.getOneGramPriceInIQD(
                  ounceDollarPrice: sellingPx,
                  dirham: IQD,
                  ounce: ounce,
                ),
                oneGramBuyingPriceInIQD: CommonService.getOneGramPriceInIQD(
                  ounceDollarPrice: buyingPx,
                  dirham: IQD,
                  ounce: ounce,
                ),
                getGoldPriceResponse: response,
              );

              onData(state);
            } catch (e) {
              getLocator<Logger>().e("SSE parse error: $e");
            }
          },
          onError: (e) {
            getLocator<Logger>().e("SSE error: $e");
            _scheduleReconnect(onData, onError);
          },
          onDone: () {
            getLocator<Logger>().w("SSE closed");
            _scheduleReconnect(onData, onError);
          },
          cancelOnError: false,
        );

    _startHeartbeat(onData, onError);
  } catch (e) {
    getLocator<Logger>().e("SSE init failed: $e");
    _scheduleReconnect(onData, onError);
  } finally {
    _isConnecting = false;
  }
}

/// ---------------------------------------------------------------------------
/// HEARTBEAT
/// ---------------------------------------------------------------------------

void _startHeartbeat(
  void Function(SSEGoldPriceState) onData,
  void Function(dynamic error)? onError,
) {
  _heartbeatTimer?.cancel();

  _heartbeatTimer = Timer.periodic(
    const Duration(seconds: 1),
    (_) {
      final diff = DateTime.now().difference(_lastEventTime).inSeconds;
      if (diff > 5) {
        getLocator<Logger>().w("SSE heartbeat timeout");
        stopSSE();
        _scheduleReconnect(onData, onError);
      }
    },
  );
}

/// ---------------------------------------------------------------------------
/// RECONNECT
/// ---------------------------------------------------------------------------

void _scheduleReconnect(
  void Function(SSEGoldPriceState) onData,
  void Function(dynamic error)? onError,
) {
  if (_reconnectTimer?.isActive ?? false) return;

  _reconnectTimer = Timer(
    const Duration(seconds: 1),
    () {
      getLocator<Logger>().i("Reconnecting SSE...");
      stopSSE();
      _startSSE(onData: onData, onError: onError);
    },
  );
}

/// ---------------------------------------------------------------------------
/// STOP
/// ---------------------------------------------------------------------------
void stopSSE() {
  _subscription?.cancel();
  _subscription = null;

  _heartbeatTimer?.cancel();
  _reconnectTimer?.cancel();

  _isConnecting = false; // 🔥 prevents stuck state

  getLocator<Logger>().i("SSE stopped");
}

// void stopSSE() {
//   _subscription?.cancel();
//   _subscription = null;

//   _heartbeatTimer?.cancel();
//   _reconnectTimer?.cancel();

//   getLocator<Logger>().i("SSE stopped");
// }
