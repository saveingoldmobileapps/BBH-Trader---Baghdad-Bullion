/// Maps [IpassOnboardingMapper] camelCase keys to HTML `data-field` snake_case keys.
import 'ipass_onboarding_mapper.dart';

class IpassHtmlFieldMapper {
  IpassHtmlFieldMapper._();

  static const Map<String, String> _mapperToHtml = {
    'mobile': 'mobile',
    'email': 'email',
    'gender': 'gender',
    'branch': 'branch',
    'arFirst': 'ar_first',
    'arFather': 'ar_father',
    'arGf': 'ar_gf',
    'arSurname': 'ar_surname',
    'arMother': 'ar_mother',
    'idEnFirst': 'id_en_first',
    'idEnFather': 'id_en_father',
    'idEnGf': 'id_en_gf',
    'idEnSurname': 'id_en_surname',
    'idEnMother': 'id_en_mother',
    'enFirst': 'en_first',
    'enFather': 'en_father',
    'enGf': 'en_gf',
    'enSurname': 'en_surname',
    'enMother': 'en_mother',
    'nationality': 'nationality',
    'dob': 'dob',
    'countryBirth': 'country_birth',
    'placeBirth': 'place_birth',
    'idPersonal': 'id_personal',
    'idSerial': 'id_serial',
    'idIssuePlace': 'id_issue_place',
    'idIssueDate': 'id_issue_date',
    'idExpiryDate': 'id_expiry_date',
    'resNo': 'res_no',
    'resPlace': 'res_place',
    'resIssue': 'res_issue',
    'resExpiry': 'res_expiry',
    'addrHouse': 'addr_house',
    'addrMahalla': 'addr_mahalla',
    'addrStreet': 'addr_street',
    'ppNo': 'pp_no',
    'ppPlace': 'pp_place',
    'ppIssue': 'pp_issue',
    'ppExpiry': 'pp_expiry',
  };

  /// Returns HTML field key → value for non-empty mapped iPass values.
  static Map<String, String> toHtmlFieldValues(Map<String, String> mapped) {
    final out = <String, String>{};
    for (final entry in mapped.entries) {
      final htmlKey = _mapperToHtml[entry.key];
      if (htmlKey == null) continue;
      final value = entry.value.trim();
      if (value.isNotEmpty) out[htmlKey] = value;
    }
    return out;
  }

  /// Keeps only form keys allowed for each scan type (prevents passport dates on ID fields).
  static Map<String, String> forScanTarget(
    IpassScanTarget target,
    Map<String, String> htmlValues,
  ) {
    const passportFields = {'pp_no', 'pp_place', 'pp_issue', 'pp_expiry'};
    const passportShared = {
      'en_first',
      'en_father',
      'en_gf',
      'en_surname',
      'en_mother',
      'dob',
      'nationality',
      'gender',
      'country_birth',
      'place_birth',
    };
    const nationalIdFields = {
      'ar_first',
      'ar_father',
      'ar_gf',
      'ar_surname',
      'ar_mother',
      'id_en_first',
      'id_en_father',
      'id_en_gf',
      'id_en_surname',
      'id_en_mother',
      'id_personal',
      'id_serial',
      'id_issue_place',
      'id_issue_date',
      'id_expiry_date',
      'dob',
      'nationality',
      'gender',
      'country_birth',
      'place_birth',
    };

    bool allowed(String key) => switch (target) {
          IpassScanTarget.passport =>
            passportFields.contains(key) || passportShared.contains(key),
          IpassScanTarget.nationalId => nationalIdFields.contains(key),
          // Residence OCR is stored for submission only — form fields are manual.
          IpassScanTarget.residence => false,
        };

    return Map.fromEntries(
      htmlValues.entries.where((e) => allowed(e.key)),
    );
  }

  /// Keeps only mapper keys allowed for the scan target (post-extraction safety net).
  static Map<String, String> filterMappedForScan(
    IpassScanTarget target,
    Map<String, String> mapped,
  ) {
    final html = toHtmlFieldValues(mapped);
    final allowed = forScanTarget(target, html);
    final out = <String, String>{};
    for (final entry in _mapperToHtml.entries) {
      final htmlKey = entry.value;
      if (!allowed.containsKey(htmlKey)) continue;
      final value = mapped[entry.key]?.trim();
      if (value != null && value.isNotEmpty) {
        out[entry.key] = value;
      }
    }
    if (allowed.containsKey('gender') && mapped['gender']?.trim().isNotEmpty == true) {
      out['gender'] = mapped['gender']!.trim();
    }
    return out;
  }

  /// National ID overwrites its fields; passport overwrites pp_* and English/personal
  /// fields (UI: "As it appears on the passport").
  static bool shouldForceApply(IpassScanTarget target, String htmlKey) {
    if (target != IpassScanTarget.passport) return true;
    return const {
      'pp_no',
      'pp_place',
      'pp_issue',
      'pp_expiry',
      'en_first',
      'en_father',
      'en_gf',
      'en_surname',
      'en_mother',
      'dob',
      'gender',
      'nationality',
      'country_birth',
      'place_birth',
    }.contains(htmlKey);
  }

  /// Kept for API compat — fields are never locked in the UI.
  static List<String> lockedHtmlFields(Map<String, String> htmlValues) {
    return const [];
  }
}
